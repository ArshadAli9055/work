﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public partial class Form9 : Form
    {
        private TextBox txtFeedbackId, txtCustomerId, txtProductId, txtRating, txtFeedback;
        private Button btnLoadFeedback, btnAddFeedback, btnUpdateFeedback, btnDeleteFeedback;
        private DataGridView dataGridViewFeedback;
        private OracleConnection dbConnection;

        public Form9()
        {
            InitializeComponent();
            InitializeDatabaseConnection();
            InitializeCustomComponents();
        }

        // Initialize Database Connection
        private void InitializeDatabaseConnection()
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";
            dbConnection = new OracleConnection(connectionString);
        }

        // Initialize Custom Components
        private void InitializeCustomComponents()
        {
            // Title Label
            Label lblTitle = new Label()
            {
                Text = "Customer Feedback Management",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(250, 10),
                Size = new Size(400, 40),
                TextAlign = ContentAlignment.MiddleCenter
            };
            Controls.Add(lblTitle);

            // Labels and Textboxes
            Controls.Add(CreateLabel("Feedback ID:", 20, 70));
            Controls.Add(CreateLabel("Customer ID:", 20, 120));
            Controls.Add(CreateLabel("Product ID:", 20, 170));
            Controls.Add(CreateLabel("Rating (1-5):", 20, 220));
            Controls.Add(CreateLabel("Feedback:", 20, 270));

            txtFeedbackId = CreateTextBox(200, 70);
            txtCustomerId = CreateTextBox(200, 120);
            txtProductId = CreateTextBox(200, 170);
            txtRating = CreateTextBox(200, 220);
            txtFeedback = CreateTextBox(200, 270, multiline: true);

            Controls.AddRange(new Control[] { txtFeedbackId, txtCustomerId, txtProductId, txtRating, txtFeedback });

            // DataGridView
            dataGridViewFeedback = new DataGridView()
            {
                Location = new Point(420, 70),
                Size = new Size(450, 250),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            Controls.Add(dataGridViewFeedback);

            // Buttons
            btnLoadFeedback = CreateButton("Load Feedback", 420, 340, Color.LightBlue);
            btnAddFeedback = CreateButton("Add Feedback", 540, 340, Color.LightGreen);
            btnUpdateFeedback = CreateButton("Update Feedback", 660, 340, Color.Gold);
            btnDeleteFeedback = CreateButton("Delete Feedback", 780, 340, Color.Salmon);

            Controls.AddRange(new Control[] { btnLoadFeedback, btnAddFeedback, btnUpdateFeedback, btnDeleteFeedback });

            // Event Handlers
            btnLoadFeedback.Click += BtnLoadFeedback_Click;
            btnAddFeedback.Click += BtnAddFeedback_Click;
            btnUpdateFeedback.Click += BtnUpdateFeedback_Click;
            btnDeleteFeedback.Click += BtnDeleteFeedback_Click;
        }

        // Helper Methods to Create UI Components
        private Label CreateLabel(string text, int x, int y)
        {
            return new Label()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(170, 30)
            };
        }

        private TextBox CreateTextBox(int x, int y, bool multiline = false)
        {
            return new TextBox()
            {
                Location = new Point(x, y),
                Size = new Size(200, multiline ? 80 : 25),
                Multiline = multiline
            };
        }

        private Button CreateButton(string text, int x, int y, Color color)
        {
            return new Button()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(100, 40),
                BackColor = color,
                FlatStyle = FlatStyle.Flat
            };
        }

        // Event Handlers for Buttons
        private void BtnLoadFeedback_Click(object sender, EventArgs e)
        {
            LoadFeedback();
        }

        private void BtnAddFeedback_Click(object sender, EventArgs e)
        {
            AddFeedback();
        }

        private void BtnUpdateFeedback_Click(object sender, EventArgs e)
        {
            UpdateFeedback();
        }

        private void BtnDeleteFeedback_Click(object sender, EventArgs e)
        {
            DeleteFeedback();
        }

        // Database Methods
        private void LoadFeedback()
        {
            try
            {
                string query = "SELECT * FROM CustomerFeedback ORDER BY FeedbackId";
                OracleDataAdapter adapter = new OracleDataAdapter(query, dbConnection);
                DataTable feedbackTable = new DataTable();
                adapter.Fill(feedbackTable);
                dataGridViewFeedback.DataSource = feedbackTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading feedback: {ex.Message}");
            }
        }

        private void AddFeedback()
        {
            try
            {
                string query = "INSERT INTO CustomerFeedback (FeedbackId, CustomerId, ProductId, Rating, Feedback) " +
                               "VALUES (:FeedbackId, :CustomerId, :ProductId, :Rating, :Feedback)";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("FeedbackId", OracleDbType.Int32).Value = int.Parse(txtFeedbackId.Text);
                    cmd.Parameters.Add("CustomerId", OracleDbType.Int32).Value = int.Parse(txtCustomerId.Text);
                    cmd.Parameters.Add("ProductId", OracleDbType.Int32).Value = int.Parse(txtProductId.Text);
                    cmd.Parameters.Add("Rating", OracleDbType.Int32).Value = int.Parse(txtRating.Text);
                    cmd.Parameters.Add("Feedback", OracleDbType.Varchar2).Value = txtFeedback.Text;

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Feedback added successfully.");
                    LoadFeedback();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding feedback: {ex.Message}");
            }
        }

        private void UpdateFeedback()
        {
            try
            {
                string query = "UPDATE CustomerFeedback SET CustomerId = :CustomerId, ProductId = :ProductId, " +
                               "Rating = :Rating, Feedback = :Feedback WHERE FeedbackId = :FeedbackId";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("CustomerId", OracleDbType.Int32).Value = int.Parse(txtCustomerId.Text);
                    cmd.Parameters.Add("ProductId", OracleDbType.Int32).Value = int.Parse(txtProductId.Text);
                    cmd.Parameters.Add("Rating", OracleDbType.Int32).Value = int.Parse(txtRating.Text);
                    cmd.Parameters.Add("Feedback", OracleDbType.Varchar2).Value = txtFeedback.Text;
                    cmd.Parameters.Add("FeedbackId", OracleDbType.Int32).Value = int.Parse(txtFeedbackId.Text);

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Feedback updated successfully.");
                    LoadFeedback();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating feedback: {ex.Message}");
            }
        }

        private void DeleteFeedback()
        {
            try
            {
                string query = "DELETE FROM CustomerFeedback WHERE FeedbackId = :FeedbackId";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("FeedbackId", OracleDbType.Int32).Value = int.Parse(txtFeedbackId.Text);

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Feedback deleted successfully.");
                    LoadFeedback();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting feedback: {ex.Message}");
            }
        }
    }
}
