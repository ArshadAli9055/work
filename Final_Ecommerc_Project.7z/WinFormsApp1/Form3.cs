﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client; // For Oracle database

namespace WinFormsApp1
{
    public partial class Form3 : Form
    {
        // UI Controls
        private TextBox txtItemId, txtOrderId, txtProductId, txtUnitPrice, txtQuantity;
        private Button btnLoadItems, btnAddItem, btnUpdateItem, btnDeleteItem;
        private DataGridView dataGridViewItems;

        // Database connection
        private OracleConnection dbConnection;

        public Form3()
        {
            InitializeComponent();
            InitializeDatabaseConnection(); // Setup Oracle connection
            InitializeCustomComponents();  // Setup UI components
        }

        private void InitializeDatabaseConnection()
        {
            string connectionString = "User Id=PROJECT;Password=123; Data Source=//localhost:1521/XE";
            dbConnection = new OracleConnection(connectionString);
        }

        private void InitializeCustomComponents()
        {
            // Form Properties
            this.Text = "Item Management - Oracle";
            this.Size = new Size(800, 450);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Title Label
            Label lblTitle = new Label()
            {
                Text = "Item Management",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(250, 10),
                Size = new Size(300, 40),
                TextAlign = ContentAlignment.MiddleCenter
            };
            Controls.Add(lblTitle);

            // Labels and Textboxes
            Controls.Add(CreateLabel("Item ID:", 20, 70));
            Controls.Add(CreateLabel("Order ID:", 20, 120));
            Controls.Add(CreateLabel("Product ID:", 20, 170));
            Controls.Add(CreateLabel("Unit Price:", 20, 220));
            Controls.Add(CreateLabel("Quantity:", 20, 270));

            txtItemId = CreateTextBox(120, 70);
            txtOrderId = CreateTextBox(120, 120);
            txtProductId = CreateTextBox(120, 170);
            txtUnitPrice = CreateTextBox(120, 220);
            txtQuantity = CreateTextBox(120, 270);

            Controls.AddRange(new Control[] { txtItemId, txtOrderId, txtProductId, txtUnitPrice, txtQuantity });

            // DataGridView
            dataGridViewItems = new DataGridView()
            {
                Location = new Point(300, 70),
                Size = new Size(470, 250),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            Controls.Add(dataGridViewItems);

            // Buttons
            btnLoadItems = CreateButton("Load Items", 300, 340, Color.LightBlue);
            btnAddItem = CreateButton("Add Item", 420, 340, Color.LightGreen);
            btnUpdateItem = CreateButton("Update Item", 540, 340, Color.Gold);
            btnDeleteItem = CreateButton("Delete Item", 660, 340, Color.Salmon);

            Controls.AddRange(new Control[] { btnLoadItems, btnAddItem, btnUpdateItem, btnDeleteItem });

            // Event handlers
            btnLoadItems.Click += BtnLoadItems_Click;
            btnAddItem.Click += BtnAddItem_Click;
            btnUpdateItem.Click += BtnUpdateItem_Click;
            btnDeleteItem.Click += BtnDeleteItem_Click;
        }

        // Helper methods to create UI components
        private Label CreateLabel(string text, int x, int y)
        {
            return new Label()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(80, 30)
            };
        }

        private TextBox CreateTextBox(int x, int y)
        {
            return new TextBox()
            {
                Location = new Point(x, y),
                Size = new Size(150, 25)
            };
        }

        private Button CreateButton(string text, int x, int y, Color color)
        {
            return new Button()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(100, 40),
                BackColor = color,
                FlatStyle = FlatStyle.Flat
            };
        }

        // Event handlers for button actions
        private void BtnLoadItems_Click(object sender, EventArgs e)
        {
            LoadItems();
        }

        private void BtnAddItem_Click(object sender, EventArgs e)
        {
            AddItem();
        }

        private void BtnUpdateItem_Click(object sender, EventArgs e)
        {
            UpdateItem();
        }

        private void BtnDeleteItem_Click(object sender, EventArgs e)
        {
            DeleteItem();
        }

        // Database actions
        private void LoadItems()
        {
            try
            {
                string query = "SELECT * FROM Item ORDER BY ItemId";
                OracleDataAdapter adapter = new OracleDataAdapter(query, dbConnection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridViewItems.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading items: {ex.Message}");
            }
        }

        private void AddItem()
        {
            try
            {
                string query = "INSERT INTO Item (ItemId, OrderId, ProductId, UnitPrice, Quantity) " +
                               "VALUES (:ItemId, :OrderId, :ProductId, :UnitPrice, :Quantity)";
                OracleCommand cmd = new OracleCommand(query, dbConnection);
                cmd.Parameters.Add(":ItemId", OracleDbType.Int32).Value = Convert.ToInt32(txtItemId.Text);
                cmd.Parameters.Add(":OrderId", OracleDbType.Int32).Value = Convert.ToInt32(txtOrderId.Text);
                cmd.Parameters.Add(":ProductId", OracleDbType.Int32).Value = Convert.ToInt32(txtProductId.Text);
                cmd.Parameters.Add(":UnitPrice", OracleDbType.Decimal).Value = Convert.ToDecimal(txtUnitPrice.Text);
                cmd.Parameters.Add(":Quantity", OracleDbType.Int32).Value = Convert.ToInt32(txtQuantity.Text);

                dbConnection.Open();
                cmd.ExecuteNonQuery();
                dbConnection.Close();

                MessageBox.Show("Item added successfully.");
                LoadItems();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding item: {ex.Message}");
                dbConnection.Close();
            }
        }

        private void UpdateItem()
        {
            try
            {
                string query = "UPDATE Item SET OrderId = :OrderId, ProductId = :ProductId, " +
                               "UnitPrice = :UnitPrice, Quantity = :Quantity WHERE ItemId = :ItemId";
                OracleCommand cmd = new OracleCommand(query, dbConnection);
                cmd.Parameters.Add(":OrderId", OracleDbType.Int32).Value = Convert.ToInt32(txtOrderId.Text);
                cmd.Parameters.Add(":ProductId", OracleDbType.Int32).Value = Convert.ToInt32(txtProductId.Text);
                cmd.Parameters.Add(":UnitPrice", OracleDbType.Decimal).Value = Convert.ToDecimal(txtUnitPrice.Text);
                cmd.Parameters.Add(":Quantity", OracleDbType.Int32).Value = Convert.ToInt32(txtQuantity.Text);
                cmd.Parameters.Add(":ItemId", OracleDbType.Int32).Value = Convert.ToInt32(txtItemId.Text);

                dbConnection.Open();
                cmd.ExecuteNonQuery();
                dbConnection.Close();

                MessageBox.Show("Item updated successfully.");
                LoadItems();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating item: {ex.Message}");
                dbConnection.Close();
            }
        }

        private void DeleteItem()
        {
            try
            {
                string query = "DELETE FROM Item WHERE ItemId = :ItemId";
                OracleCommand cmd = new OracleCommand(query, dbConnection);
                cmd.Parameters.Add(":ItemId", OracleDbType.Int32).Value = Convert.ToInt32(txtItemId.Text);

                dbConnection.Open();
                cmd.ExecuteNonQuery();
                dbConnection.Close();

                MessageBox.Show("Item deleted successfully.");
                LoadItems();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting item: {ex.Message}");
                dbConnection.Close();
            }
        }
    }
}

