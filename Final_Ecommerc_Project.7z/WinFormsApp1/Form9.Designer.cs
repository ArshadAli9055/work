﻿namespace WinFormsApp1
{
    partial class Form9
    {
        private System.ComponentModel.IContainer components = null;

        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            SuspendLayout();
            
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Name = "Form9";
            Text = "Form9";
            
        }
        private void Form9_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome to the FeedBack Form!");
        }
        #endregion
    }
}