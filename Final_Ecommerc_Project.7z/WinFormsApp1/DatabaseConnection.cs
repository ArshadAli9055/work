﻿using System;
using System.Data;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public class DatabaseConnection
    {
        private readonly string connectionString;

        // Constructor to initialize connection string for Oracle DB connection
        public DatabaseConnection()
        {
            // Replace with your actual Oracle connection string.
            connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE;"; // Example connection string
        }

        // Method to get the OracleConnection object initialized with connection string
        private OracleConnection GetConnection()
        {
            return new OracleConnection(connectionString);
        }

        /// <summary>
        /// Executes a plain SQL query and returns the result as a DataTable.
        /// </summary>
        /// <param name="query">The SQL query to execute.</param>
        /// <returns>A DataTable containing the result of the query.</returns>
        public DataTable ExecuteQuery(string query)
        {
            DataTable dataTable = new DataTable();

            using (OracleConnection conn = GetConnection())
            {
                conn.Open();
                using (OracleCommand cmd = new OracleCommand(query, conn))
                {
                    // Execute the command and fill the DataTable with the result
                    using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }

            return dataTable;
        }

        /// <summary>
        /// Executes a stored procedure for non-query operations (e.g., INSERT, UPDATE, DELETE).
        /// </summary>
        /// <param name="procedureName">The name of the stored procedure.</param>
        /// <param name="parameters">An array of OracleParameter objects for the input parameters.</param>
        /// <returns>The number of rows affected by the operation.</returns>
        public int ExecuteStoredProcedureNonQuery(string procedureName, OracleParameter[] parameters = null)
        {
            int rowsAffected;

            using (OracleConnection conn = GetConnection())
            {
                conn.Open();
                using (OracleCommand cmd = new OracleCommand(procedureName, conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }

                    // Execute the non-query operation (INSERT, UPDATE, DELETE)
                    rowsAffected = cmd.ExecuteNonQuery();
                }
            }

            return rowsAffected;
        }

        /// <summary>
        /// Executes a stored procedure that returns a scalar value (e.g., COUNT, SUM, or a unique field value).
        /// </summary>
        /// <param name="procedureName">The name of the stored procedure.</param>
        /// <param name="parameters">An array of OracleParameter objects for the input parameters.</param>
        /// <returns>The scalar result from the procedure.</returns>
        public object ExecuteStoredProcedureScalar(string procedureName, OracleParameter[] parameters = null)
        {
            object result;

            using (OracleConnection conn = GetConnection())
            {
                conn.Open();
                using (OracleCommand cmd = new OracleCommand(procedureName, conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }

                    // Execute the procedure and return the scalar value
                    result = cmd.ExecuteScalar();
                }
            }

            return result;
        }
    }
}
