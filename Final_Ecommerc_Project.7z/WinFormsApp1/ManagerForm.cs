﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public partial class ManagerForm : Form
    {
        private static readonly string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";

        private Panel contentPanel;

        public ManagerForm()
        {
            InitializeForm();
        }

        private void InitializeForm()
        {
            // Form properties
            this.Text = "Manager Dashboard";
            this.Size = new Size(900, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            // Gradient Background
            this.Paint += (s, e) =>
            {
                using (LinearGradientBrush brush = new LinearGradientBrush(this.ClientRectangle, Color.LightSkyBlue, Color.LightSteelBlue, 45F))
                {
                    e.Graphics.FillRectangle(brush, this.ClientRectangle);
                }
            };

            // Welcome Label
            Label lblWelcome = new Label()
            {
                Text = "Welcome to the Manager Dashboard!",
                Font = new Font("Arial", 18, FontStyle.Bold),
                ForeColor = Color.DarkSlateBlue,
                AutoSize = true,
                Location = new Point(260, 30)
            };
            Controls.Add(lblWelcome);

            // Button Panel
            Panel buttonPanel = new Panel()
            {
                Size = new Size(800, 80),
                Location = new Point(50, 100),
                BackColor = Color.White
            };
            Controls.Add(buttonPanel);

            // Add Buttons
            AddButton(buttonPanel, "View Orders", 50, BtnViewOrders_Click, Color.LightBlue);
            AddButton(buttonPanel, "View Feedback", 200, BtnViewFeedback_Click, Color.LightGreen);
            AddButton(buttonPanel, "Logout", 350, BtnLogout_Click, Color.LightCoral);

            // Content Panel
            contentPanel = new Panel()
            {
                Size = new Size(800, 400),
                Location = new Point(50, 200),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            Controls.Add(contentPanel);
        }

        private void AddButton(Panel panel, string text, int x, EventHandler onClick, Color color)
        {
            Button button = new Button()
            {
                Text = text,
                Location = new Point(x, 20),
                Size = new Size(120, 40),
                BackColor = color,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            button.FlatAppearance.BorderSize = 0;
            button.MouseEnter += (s, e) => button.BackColor = ControlPaint.Light(color, 0.2f);
            button.MouseLeave += (s, e) => button.BackColor = color;
            button.Click += onClick;
            panel.Controls.Add(button);
        }

        private void DisplayDataInContentPanel(DataTable dt, string title)
        {
            // Clear the content panel
            contentPanel.Controls.Clear();

            // Title Label
            Label lblTitle = new Label()
            {
                Text = title,
                Font = new Font("Arial", 14, FontStyle.Bold),
                ForeColor = Color.DarkSlateBlue,
                AutoSize = true,
                Location = new Point(20, 20)
            };
            contentPanel.Controls.Add(lblTitle);

            // DataGridView
            DataGridView dgv = new DataGridView()
            {
                DataSource = dt,
                Location = new Point(20, 60),
                Size = new Size(760, 320),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.Fixed3D,
                ReadOnly = true
            };
            contentPanel.Controls.Add(dgv);
        }

        private void BtnViewOrders_Click(object sender, EventArgs e)
        {
            try
            {
                using (OracleConnection conn = new OracleConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT OrderId, OrderDate, OrderNumber, CustomerId, TotalAmount, Status FROM ProductOrdered";
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    // Display data
                    DisplayDataInContentPanel(dt, "Orders Placed by Customers");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error retrieving orders: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnViewFeedback_Click(object sender, EventArgs e)
        {
            try
            {
                using (OracleConnection conn = new OracleConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT cf.FeedbackId, cf.Rating, cf.Feedback, p.ProductName, u.Username AS CustomerName " +
                                   "FROM CustomerFeedback cf " +
                                   "JOIN Product p ON cf.ProductId = p.ProductId " +
                                   "JOIN Users u ON cf.CustomerId = u.UserId";
                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    // Display data
                    DisplayDataInContentPanel(dt, "Customer Feedback");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error retrieving feedback: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            Form10 loginForm = new Form10();
            loginForm.Show();
        }
    }
}
