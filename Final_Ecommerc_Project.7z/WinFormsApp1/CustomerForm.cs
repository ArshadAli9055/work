﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public partial class CustomerForm : Form
    {
        private DataGridView dgvCustomerData;
        private TextBox txtSearchOrderId;
        private Button btnViewOrders;
        private Button btnGiveFeedback;
        private Button btnViewPayments;
        private Button btnCancelOrder;
        private Button btnTrackOrder;

        public CustomerForm()
        {
            InitializeForm();
        }

        private void InitializeForm()
        {
            // Form Settings
            this.Text = "Customer Dashboard";
            this.Size = new Size(950, 700);
            this.BackColor = Color.FromArgb(240, 240, 240); // Light background color

            // Welcome Label
            Label lblWelcome = new Label()
            {
                Text = "Welcome to Your Dashboard!",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(340, 20),
                AutoSize = true
            };
            Controls.Add(lblWelcome);

            // Search Order ID Label
            Label lblSearchOrderId = new Label()
            {
                Text = "Search Order ID:",
                Location = new Point(50, 100),
                Size = new Size(120, 25),
                Font = new Font("Arial", 10)
            };
            Controls.Add(lblSearchOrderId);

            // Search Order ID TextBox
            txtSearchOrderId = new TextBox()
            {
                Location = new Point(180, 100),
                Size = new Size(200, 25),
                Font = new Font("Arial", 10)
            };
            Controls.Add(txtSearchOrderId);

            // View Orders Button
            btnViewOrders = new Button()
            {
                Text = "View Orders",
                Location = new Point(400, 100),
                Size = new Size(120, 40),
                BackColor = Color.LightSkyBlue,
                Font = new Font("Arial", 10, FontStyle.Bold)
            };
            btnViewOrders.Click += BtnViewOrders_Click;
            Controls.Add(btnViewOrders);

            // Give Feedback Button
            btnGiveFeedback = new Button()
            {
                Text = "Give Feedback",
                Location = new Point(550, 100),
                Size = new Size(150, 40),
                BackColor = Color.LightGreen,
                Font = new Font("Arial", 10, FontStyle.Bold)
            };
            btnGiveFeedback.Click += BtnGiveFeedback_Click;
            Controls.Add(btnGiveFeedback);

            // View Payments Button
            btnViewPayments = new Button()
            {
                Text = "View Payments",
                Location = new Point(730, 100),
                Size = new Size(120, 40),
                BackColor = Color.LightCoral,
                Font = new Font("Arial", 10, FontStyle.Bold)
            };
            btnViewPayments.Click += BtnViewPayments_Click;
            Controls.Add(btnViewPayments);

            // Cancel Order Button
            btnCancelOrder = new Button()
            {
                Text = "Cancel Order",
                Location = new Point(730, 160),
                Size = new Size(120, 40),
                BackColor = Color.LightPink,
                Font = new Font("Arial", 10, FontStyle.Bold)
            };
            btnCancelOrder.Click += BtnCancelOrder_Click;
            Controls.Add(btnCancelOrder);

            // Track Order Button
            btnTrackOrder = new Button()
            {
                Text = "Track Order",
                Location = new Point(550, 160),
                Size = new Size(150, 40),
                BackColor = Color.LightYellow,
                Font = new Font("Arial", 10, FontStyle.Bold)
            };
            btnTrackOrder.Click += BtnTrackOrder_Click;
            Controls.Add(btnTrackOrder);

            // DataGridView to display customer data
            dgvCustomerData = new DataGridView()
            {
                Location = new Point(50, 220),
                Size = new Size(850, 350),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Font = new Font("Arial", 10)
            };
            dgvCustomerData.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Controls.Add(dgvCustomerData);

            // Logout Button
            Button btnLogout = new Button()
            {
                Text = "Logout",
                Location = new Point(300, 590),
                Size = new Size(200, 40),
                BackColor = Color.LightCoral,
                Font = new Font("Arial", 10, FontStyle.Bold)
            };
            btnLogout.Click += BtnLogout_Click;
            Controls.Add(btnLogout);
        }

        // Event Handlers

        private void BtnViewOrders_Click(object sender, EventArgs e)
        {
            string orderId = txtSearchOrderId.Text.Trim();
            LoadOrderData(orderId);
        }

        private void BtnGiveFeedback_Click(object sender, EventArgs e)
        {
            if (dgvCustomerData.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvCustomerData.SelectedRows[0];
                int productId = Convert.ToInt32(selectedRow.Cells["ProductId"].Value);

                // Prompt for feedback and rating
                string feedback = PromptForFeedback();
                if (!string.IsNullOrEmpty(feedback))
                {
                    SaveFeedback(productId, feedback);
                }
            }
            else
            {
                MessageBox.Show("Please select a product to give feedback on.", "Feedback", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnViewPayments_Click(object sender, EventArgs e)
        {
            string orderId = txtSearchOrderId.Text.Trim();
            LoadPaymentData(orderId);
        }

        private void BtnCancelOrder_Click(object sender, EventArgs e)
        {
            if (dgvCustomerData.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvCustomerData.SelectedRows[0];
                string orderId = selectedRow.Cells["OrderId"].Value.ToString();

                // Confirm cancellation
                var confirmation = MessageBox.Show("Are you sure you want to cancel this order?", "Cancel Order", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (confirmation == DialogResult.Yes)
                {
                    CancelOrder(orderId);
                }
            }
            else
            {
                MessageBox.Show("Please select an order to cancel.", "Cancel Order", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnTrackOrder_Click(object sender, EventArgs e)
        {
            string orderId = txtSearchOrderId.Text.Trim();
            TrackOrder(orderId);
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            // Close the current CustomerForm and open login form
            this.Close();
            Form10 loginForm = new Form10();
            loginForm.Show();
        }

        // Database Methods

        private void LoadOrderData(string orderId)
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";

            try
            {
                using (OracleConnection connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT o.OrderId, o.OrderDate, o.TotalAmount, o.Status, i.ProductId FROM ProductOrdered o " +
                                   "JOIN Item i ON o.OrderId = i.OrderId";
                    if (!string.IsNullOrEmpty(orderId))
                    {
                        query += " WHERE o.OrderId = :OrderId";
                    }

                    using (OracleCommand command = new OracleCommand(query, connection))
                    {
                        if (!string.IsNullOrEmpty(orderId))
                        {
                            command.Parameters.Add(new OracleParameter("OrderId", orderId));
                        }

                        OracleDataAdapter adapter = new OracleDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dgvCustomerData.DataSource = dataTable;

                        if (dataTable.Rows.Count == 0)
                        {
                            MessageBox.Show("No records found for the given Order ID.", "View Orders", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading order data: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadPaymentData(string orderId)
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";

            try
            {
                using (OracleConnection connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT PaymentId, PaymentAmount, PaymentDate, PaymentStatus FROM Payment WHERE OrderId = :OrderId";

                    using (OracleCommand command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("OrderId", orderId));
                        OracleDataAdapter adapter = new OracleDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dgvCustomerData.DataSource = dataTable;

                        if (dataTable.Rows.Count == 0)
                        {
                            MessageBox.Show("No payment data found for the given Order ID.", "View Payments", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading payment data: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CancelOrder(string orderId)
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";

            try
            {
                using (OracleConnection connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    string query = "UPDATE ProductOrdered SET Status = 'Cancelled' WHERE OrderId = :OrderId";

                    using (OracleCommand command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("OrderId", orderId));
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Order successfully cancelled.", "Cancel Order", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadOrderData(orderId); // Refresh the order data
                        }
                        else
                        {
                            MessageBox.Show("Failed to cancel the order.", "Cancel Order", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error cancelling the order: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TrackOrder(string orderId)
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";

            try
            {
                using (OracleConnection connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT OrderTrackingId, Status FROM OrderTrack WHERE OrderId = :OrderId";

                    using (OracleCommand command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("OrderId", orderId));
                        OracleDataAdapter adapter = new OracleDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        if (dataTable.Rows.Count > 0)
                        {
                            string trackingInfo = "Tracking Info: \n";
                            foreach (DataRow row in dataTable.Rows)
                            {
                                trackingInfo += $"Tracking ID: {row["OrderTrackingId"]}\n";
                                trackingInfo += $"Status: {row["Status"]}\n";
                            }
                            MessageBox.Show(trackingInfo, "Order Tracking", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No tracking information found for the given Order ID.", "Order Tracking", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error tracking the order: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string PromptForFeedback()
        {
            using (Form prompt = new Form())
            {
                prompt.Text = "Give Feedback";
                prompt.Size = new Size(300, 200);

                Label lblFeedback = new Label()
                {
                    Text = "Enter your feedback:",
                    Location = new Point(20, 20),
                    AutoSize = true
                };
                prompt.Controls.Add(lblFeedback);

                TextBox txtFeedback = new TextBox()
                {
                    Location = new Point(20, 50),
                    Width = 240,
                    Font = new Font("Arial", 10)
                };
                prompt.Controls.Add(txtFeedback);

                Button btnConfirm = new Button()
                {
                    Text = "Submit",
                    Location = new Point(100, 100),
                    DialogResult = DialogResult.OK,
                    Font = new Font("Arial", 10, FontStyle.Bold)
                };
                prompt.Controls.Add(btnConfirm);

                prompt.AcceptButton = btnConfirm;

                if (prompt.ShowDialog() == DialogResult.OK)
                {
                    return txtFeedback.Text.Trim();
                }
                return null;
            }
        }

        private void SaveFeedback(int productId, string feedback)
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";

            try
            {
                using (OracleConnection connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    // Check if feedback already exists
                    string checkQuery = "SELECT COUNT(*) FROM CustomerFeedback WHERE ProductId = :ProductId AND Feedback = :Feedback";
                    using (OracleCommand checkCommand = new OracleCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.Add(new OracleParameter("ProductId", productId));
                        checkCommand.Parameters.Add(new OracleParameter("Feedback", feedback));

                        int count = Convert.ToInt32(checkCommand.ExecuteScalar());
                        if (count > 0)
                        {
                            MessageBox.Show("Feedback for this product already exists.", "Feedback", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return; // Stop execution if feedback already exists
                        }
                    }

                    // Insert feedback
                    string query = "INSERT INTO CustomerFeedback (FeedbackId, ProductId, Feedback) VALUES (SEQ_FEEDBACK.NEXTVAL, :ProductId, :Feedback)";
                    using (OracleCommand command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("ProductId", productId));
                        command.Parameters.Add(new OracleParameter("Feedback", feedback));

                        command.ExecuteNonQuery();

                        MessageBox.Show("Feedback submitted successfully.", "Feedback", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error submitting feedback: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
