﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public partial class InventoryStaffForm : Form
    {
        private DataGridView dgvDisplay;
        private ComboBox cmbTableSelect;
        private TextBox txtSearch;
        private Button btnSearch;
        private Button btnLogout;

        public InventoryStaffForm()
        {
            InitializeForm();
        }

        private void InitializeForm()
        {
            // Form settings
            this.Text = "Inventory Staff Dashboard";
            this.Size = new Size(1000, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            // Welcome Label
            Label lblWelcome = new Label()
            {
                Text = "Welcome, Inventory Staff!",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(370, 20),
                AutoSize = true
            };
            Controls.Add(lblWelcome);

            // Panel for search and dropdown
            Panel searchPanel = new Panel()
            {
                Location = new Point(50, 70),
                Size = new Size(900, 50),
                BackColor = Color.Transparent
            };

            // Table Selection ComboBox
            cmbTableSelect = new ComboBox()
            {
                Location = new Point(0, 10),
                Size = new Size(200, 30),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Arial", 12)
            };
            cmbTableSelect.Items.AddRange(new string[] { "Product", "Supplier", "Item", "Discount" });
            cmbTableSelect.SelectedIndex = 0;
            searchPanel.Controls.Add(cmbTableSelect);

            // Search TextBox
            txtSearch = new TextBox()
            {
                Location = new Point(220, 10),
                Size = new Size(300, 30),
                Font = new Font("Arial", 12),
                PlaceholderText = "Enter search keyword..."
            };
            searchPanel.Controls.Add(txtSearch);

            // Search Button
            btnSearch = new Button()
            {
                Text = "Search",
                Location = new Point(540, 10),
                Size = new Size(100, 30),
                BackColor = Color.LightGreen,
                Font = new Font("Arial", 12)
            };
            btnSearch.Click += BtnSearch_Click;
            searchPanel.Controls.Add(btnSearch);

            Controls.Add(searchPanel);

            // DataGridView
            dgvDisplay = new DataGridView()
            {
                Location = new Point(50, 150),
                Size = new Size(880, 400),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Font = new Font("Arial", 10),
                AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle() { BackColor = Color.LightGray }
            };
            Controls.Add(dgvDisplay);

            // Logout Button
            btnLogout = new Button()
            {
                Text = "Logout",
                Location = new Point(400, 570),
                Size = new Size(200, 40),
                BackColor = Color.LightCoral,
                Font = new Font("Arial", 12)
            };
            btnLogout.Click += BtnLogout_Click;
            Controls.Add(btnLogout);
        

        // Load default table data
        LoadTableData("Product", "");

            // Tooltips for better user experience
            ToolTip toolTip = new ToolTip();
            toolTip.SetToolTip(cmbTableSelect, "Select a table to view records.");
            toolTip.SetToolTip(txtSearch, "Enter search keyword.");
            toolTip.SetToolTip(btnSearch, "Click to search for records based on selected criteria.");
            toolTip.SetToolTip(btnLogout, "Click to log out.");
        }

        // Event handler for Search Button
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            string selectedTable = cmbTableSelect.SelectedItem.ToString();
            string searchQuery = txtSearch.Text.Trim();
            LoadTableData(selectedTable, searchQuery);
        }

        // Method to load data from the selected table
        private void LoadTableData(string tableName, string searchQuery)
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";

            try
            {
                using (OracleConnection connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    string query = "";

                    // Define queries for each table
                    if (tableName == "Product")
                    {
                        query = "SELECT ProductId, ProductName, UnitPrice, Status FROM Product";
                        if (!string.IsNullOrEmpty(searchQuery))
                            query += " WHERE LOWER(ProductName) LIKE '%' || :SearchQuery || '%'";
                    }
                    else if (tableName == "Supplier")
                    {
                        query = "SELECT SupplierId, CompanyName, Address, Country, Phone FROM Supplier";
                        if (!string.IsNullOrEmpty(searchQuery))
                            query += " WHERE LOWER(CompanyName) LIKE '%' || :SearchQuery || '%'";
                    }
                    else if (tableName == "Item")
                    {
                        query = "SELECT ItemId, OrderId, ProductId, UnitPrice, Quantity FROM Item";
                        if (!string.IsNullOrEmpty(searchQuery))
                            query += " WHERE ProductId = :SearchQuery";
                    }
                    else if (tableName == "Discount")
                    {
                        query = "SELECT DiscountId, DiscountCode, DiscountType, DiscountValue, StartDate, EndDate FROM Discount";
                        if (!string.IsNullOrEmpty(searchQuery))
                            query += " WHERE LOWER(DiscountCode) LIKE '%' || :SearchQuery || '%'";
                    }

                    // Execute query
                    using (OracleCommand command = new OracleCommand(query, connection))
                    {
                        if (!string.IsNullOrEmpty(searchQuery))
                            command.Parameters.Add(new OracleParameter("SearchQuery", searchQuery.ToLower()));

                        OracleDataAdapter adapter = new OracleDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Bind results to DataGridView
                        dgvDisplay.DataSource = dataTable;

                        // Inform if no records found
                        if (dataTable.Rows.Count == 0)
                        {
                            MessageBox.Show("No records found for the selected table and search criteria.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Logout event handler
        private void BtnLogout_Click(object sender, EventArgs e)
        {
            // Close the current form
            this.Close();

            // Navigate to the Login form
            Form10 loginForm = new Form10();
            loginForm.Show();
        }

        // Optional: Event handler for double-clicking on the DataGridView rows for more options (e.g., edit records)
        private void DgvDisplay_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            // Example: Implement editing on double-click on a row
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvDisplay.Rows[e.RowIndex];
                string id = row.Cells[0].Value.ToString();
                MessageBox.Show($"You double-clicked on record with ID: {id}");
            }
        }
    }
}
