﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public partial class Form5 : Form
    {
        private TextBox txtSupplierId, txtCompanyName, txtAddress, txtCountry, txtPhone;
        private Button btnLoadSuppliers, btnAddSupplier, btnUpdateSupplier, btnDeleteSupplier;
        private DataGridView dataGridViewSuppliers;
        private OracleConnection dbConnection;

        public Form5()
        {
            InitializeComponent();
            InitializeDatabaseConnection();
            InitializeCustomComponents();
        }

        // Initialize Database Connection
        private void InitializeDatabaseConnection()
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";
            dbConnection = new OracleConnection(connectionString);
        }

        // Initialize Custom Components
        private void InitializeCustomComponents()
        {
            // Title Label
            Label lblTitle = new Label()
            {
                Text = "Supplier Management",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(250, 10),
                Size = new Size(400, 40),
                TextAlign = ContentAlignment.MiddleCenter
            };
            Controls.Add(lblTitle);

            // Labels and Textboxes
            Controls.Add(CreateLabel("Supplier ID:", 20, 70));
            Controls.Add(CreateLabel("Company Name:", 20, 120));
            Controls.Add(CreateLabel("Address:", 20, 170));
            Controls.Add(CreateLabel("Country:", 20, 220));
            Controls.Add(CreateLabel("Phone:", 20, 270));

            txtSupplierId = CreateTextBox(150, 70);
            txtCompanyName = CreateTextBox(150, 120);
            txtAddress = CreateTextBox(150, 170);
            txtCountry = CreateTextBox(150, 220);
            txtPhone = CreateTextBox(150, 270);

            Controls.AddRange(new Control[] { txtSupplierId, txtCompanyName, txtAddress, txtCountry, txtPhone });

            // DataGridView
            dataGridViewSuppliers = new DataGridView()
            {
                Location = new Point(400, 70),
                Size = new Size(450, 250),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            Controls.Add(dataGridViewSuppliers);

            // Buttons
            btnLoadSuppliers = CreateButton("Load Suppliers", 400, 340, Color.LightBlue);
            btnAddSupplier = CreateButton("Add Supplier", 520, 340, Color.LightGreen);
            btnUpdateSupplier = CreateButton("Update Supplier", 640, 340, Color.Gold);
            btnDeleteSupplier = CreateButton("Delete Supplier", 760, 340, Color.Salmon);

            Controls.AddRange(new Control[] { btnLoadSuppliers, btnAddSupplier, btnUpdateSupplier, btnDeleteSupplier });

            // Event Handlers
            btnLoadSuppliers.Click += BtnLoadSuppliers_Click;
            btnAddSupplier.Click += BtnAddSupplier_Click;
            btnUpdateSupplier.Click += BtnUpdateSupplier_Click;
            btnDeleteSupplier.Click += BtnDeleteSupplier_Click;
        }

        // Helper Methods to Create UI Components
        private Label CreateLabel(string text, int x, int y)
        {
            return new Label()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(120, 30)
            };
        }

        private TextBox CreateTextBox(int x, int y)
        {
            return new TextBox()
            {
                Location = new Point(x, y),
                Size = new Size(200, 25)
            };
        }

        private Button CreateButton(string text, int x, int y, Color color)
        {
            return new Button()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(100, 40),
                BackColor = color,
                FlatStyle = FlatStyle.Flat
            };
        }

        // Event Handlers for Buttons
        private void BtnLoadSuppliers_Click(object sender, EventArgs e)
        {
            LoadSuppliers();
        }

        private void BtnAddSupplier_Click(object sender, EventArgs e)
        {
            AddSupplier();
        }

        private void BtnUpdateSupplier_Click(object sender, EventArgs e)
        {
            UpdateSupplier();
        }

        private void BtnDeleteSupplier_Click(object sender, EventArgs e)
        {
            DeleteSupplier();
        }

        // Database Methods
        private void LoadSuppliers()
        {
            try
            {
                string query = "SELECT * FROM Supplier ORDER BY SupplierId";
                OracleDataAdapter adapter = new OracleDataAdapter(query, dbConnection);
                DataTable suppliersTable = new DataTable();
                adapter.Fill(suppliersTable);
                dataGridViewSuppliers.DataSource = suppliersTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading suppliers: {ex.Message}");
            }
        }

        private void AddSupplier()
        {
            try
            {
                string query = "INSERT INTO Supplier (SupplierId, CompanyName, Address, Country, Phone) " +
                               "VALUES (:SupplierId, :CompanyName, :Address, :Country, :Phone)";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("SupplierId", OracleDbType.Int32).Value = int.Parse(txtSupplierId.Text);
                    cmd.Parameters.Add("CompanyName", OracleDbType.Varchar2).Value = txtCompanyName.Text;
                    cmd.Parameters.Add("Address", OracleDbType.Varchar2).Value = txtAddress.Text;
                    cmd.Parameters.Add("Country", OracleDbType.Varchar2).Value = txtCountry.Text;
                    cmd.Parameters.Add("Phone", OracleDbType.Varchar2).Value = txtPhone.Text;

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Supplier added successfully.");
                    LoadSuppliers();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding supplier: {ex.Message}");
            }
        }

        private void UpdateSupplier()
        {
            try
            {
                string query = "UPDATE Supplier SET CompanyName = :CompanyName, Address = :Address, " +
                               "Country = :Country, Phone = :Phone WHERE SupplierId = :SupplierId";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("CompanyName", OracleDbType.Varchar2).Value = txtCompanyName.Text;
                    cmd.Parameters.Add("Address", OracleDbType.Varchar2).Value = txtAddress.Text;
                    cmd.Parameters.Add("Country", OracleDbType.Varchar2).Value = txtCountry.Text;
                    cmd.Parameters.Add("Phone", OracleDbType.Varchar2).Value = txtPhone.Text;
                    cmd.Parameters.Add("SupplierId", OracleDbType.Int32).Value = int.Parse(txtSupplierId.Text);

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Supplier updated successfully.");
                    LoadSuppliers();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating supplier: {ex.Message}");
            }
        }

        private void DeleteSupplier()
        {
            try
            {
                string query = "DELETE FROM Supplier WHERE SupplierId = :SupplierId";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("SupplierId", OracleDbType.Int32).Value = int.Parse(txtSupplierId.Text);

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Supplier deleted successfully.");
                    LoadSuppliers();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting supplier: {ex.Message}");
            }
        }
    }
}

