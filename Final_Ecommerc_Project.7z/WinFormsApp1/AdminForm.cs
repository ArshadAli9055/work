﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public partial class AdminForm : Form
    {
        private static readonly string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";

        public AdminForm()
        {
            InitializeComponent();
            InitializeForm();
        }

        private void InitializeForm()
        {
            this.Text = "Admin Dashboard";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Welcome Label
            Label lblWelcome = new Label()
            {
                Text = "Welcome, Admin!",
                Font = new Font("Arial", 16, FontStyle.Bold),
                Location = new Point(300, 50),
                AutoSize = true
            };
            Controls.Add(lblWelcome);

            // Create Buttons
            Button btnViewUsers = CreateButton("View Users", new Point(300, 120), Color.LightBlue, BtnViewUsers_Click);
            Button btnAddUser = CreateButton("Add User", new Point(300, 180), Color.LightGreen, BtnAddUser_Click);
            Button btnEditUser = CreateButton("Edit User", new Point(300, 240), Color.LightYellow, BtnEditUser_Click);
            Button btnDeleteUser = CreateButton("Delete User", new Point(300, 300), Color.LightCoral, BtnDeleteUser_Click);
            Button btnAssignRole = CreateButton("Assign Role", new Point(300, 360), Color.LightSkyBlue, BtnAssignRole_Click);
            Button btnLogout = CreateButton("Logout", new Point(300, 420), Color.LightCoral, BtnLogout_Click);

            // Add Buttons to the Form
            Controls.AddRange(new Control[] { btnViewUsers, btnAddUser, btnEditUser, btnDeleteUser, btnAssignRole, btnLogout });
        }

        private Button CreateButton(string text, Point location, Color backColor, EventHandler clickHandler)
        {
            Button button = new Button
            {
                Text = text,
                Location = location,
                Size = new Size(200, 40),
                BackColor = backColor
            };
            button.Click += clickHandler;
            return button;
        }

        private void BtnViewUsers_Click(object sender, EventArgs e)
        {
            try
            {
                using (OracleConnection conn = new OracleConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM Users";
                    OracleDataAdapter dataAdapter = new OracleDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    dataAdapter.Fill(dt);

                    // Display users in DataGridView
                    DataGridView dgvUsers = new DataGridView
                    {
                        DataSource = dt,
                        Location = new Point(50, 470),
                        Size = new Size(700, 100),
                        AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
                    };
                    Controls.Add(dgvUsers);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void BtnAddUser_Click(object sender, EventArgs e)
        {
            string userId = Microsoft.VisualBasic.Interaction.InputBox("Enter User ID", "Add User");
            string username = Microsoft.VisualBasic.Interaction.InputBox("Enter Username", "Add User");
            string password = Microsoft.VisualBasic.Interaction.InputBox("Enter Password", "Add User");
            string role = Microsoft.VisualBasic.Interaction.InputBox("Enter Role", "Add User");

            try
            {
                using (OracleConnection conn = new OracleConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO Users (UserId, Username, Password, Role) VALUES (:userId, :username, :password, :role)";
                    OracleCommand cmd = new OracleCommand(query, conn);
                    cmd.Parameters.Add(":userId", OracleDbType.Varchar2).Value = userId;
                    cmd.Parameters.Add(":username", OracleDbType.Varchar2).Value = username;
                    cmd.Parameters.Add(":password", OracleDbType.Varchar2).Value = password;
                    cmd.Parameters.Add(":role", OracleDbType.Varchar2).Value = role;

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User added successfully.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void BtnEditUser_Click(object sender, EventArgs e)
        {
            string userId = Microsoft.VisualBasic.Interaction.InputBox("Enter User ID", "Edit User");
            string newUsername = Microsoft.VisualBasic.Interaction.InputBox("Enter New Username", "Edit User");
            string newPassword = Microsoft.VisualBasic.Interaction.InputBox("Enter New Password", "Edit User");
            string newRole = Microsoft.VisualBasic.Interaction.InputBox("Enter New Role", "Edit User");

            try
            {
                using (OracleConnection conn = new OracleConnection(connectionString))
                {
                    conn.Open();
                    string query = "UPDATE Users SET Username = :username, Password = :password, Role = :role WHERE UserId = :userId";
                    OracleCommand cmd = new OracleCommand(query, conn);
                    cmd.Parameters.Add(":username", OracleDbType.Varchar2).Value = newUsername;
                    cmd.Parameters.Add(":password", OracleDbType.Varchar2).Value = newPassword;
                    cmd.Parameters.Add(":role", OracleDbType.Varchar2).Value = newRole;
                    cmd.Parameters.Add(":userId", OracleDbType.Int32).Value = userId;

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User updated successfully.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void BtnDeleteUser_Click(object sender, EventArgs e)
        {
            string userId = Microsoft.VisualBasic.Interaction.InputBox("Enter User ID to Delete", "Delete User");

            try
            {
                using (OracleConnection conn = new OracleConnection(connectionString))
                {
                    conn.Open();
                    string query = "DELETE FROM Users WHERE UserId = :userId";
                    OracleCommand cmd = new OracleCommand(query, conn);
                    cmd.Parameters.Add(":userId", OracleDbType.Int32).Value = userId;

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User deleted successfully.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void BtnAssignRole_Click(object sender, EventArgs e)
        {
            string userId = Microsoft.VisualBasic.Interaction.InputBox("Enter User ID", "Assign Role");
            string role = Microsoft.VisualBasic.Interaction.InputBox("Enter New Role", "Assign Role");

            try
            {
                using (OracleConnection conn = new OracleConnection(connectionString))
                {
                    conn.Open();
                    string query = "UPDATE Users SET Role = :role WHERE UserId = :userId";
                    OracleCommand cmd = new OracleCommand(query, conn);
                    cmd.Parameters.Add(":role", OracleDbType.Varchar2).Value = role;
                    cmd.Parameters.Add(":userId", OracleDbType.Int32).Value = userId;

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Role assigned successfully.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            this.Close(); // Close the AdminForm
            Form10 loginForm = new Form10(); // Navigate back to the Login Form
            loginForm.Show();
        }
    }
}
