﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public partial class CashierForm : Form
    {
        private TextBox txtOrderId;
        private ComboBox cmbStatus;
        private DataGridView dgvDisplay;
        private Button btnSearch;
        private Button btnLogout;

        public CashierForm()
        {
            InitializeForm();
        }

        private void InitializeForm()
        {
            // Form settings
            this.Text = "Cashier Dashboard";
            this.Size = new Size(900, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;

            // Gradient background
            this.Paint += (s, e) =>
            {
                using (LinearGradientBrush brush = new LinearGradientBrush(this.ClientRectangle, Color.LightSkyBlue, Color.LightSteelBlue, 90F))
                {
                    e.Graphics.FillRectangle(brush, this.ClientRectangle);
                }
            };

            // Welcome Label with Shadow Effect
            Label lblWelcome = new Label()
            {
                Text = "Welcome, Cashier!",
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                Location = new Point(300, 20),
                AutoSize = true,
                ForeColor = Color.DarkSlateGray
            };
            Controls.Add(lblWelcome);

            // Panel for Filters
            Panel filterPanel = new Panel()
            {
                Location = new Point(50, 80),
                Size = new Size(800, 150),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            Controls.Add(filterPanel);

            // Order ID Label and TextBox
            Label lblOrderId = new Label()
            {
                Text = "Order ID:",
                Location = new Point(20, 20),
                Size = new Size(100, 30),
                Font = new Font("Segoe UI", 12)
            };
            filterPanel.Controls.Add(lblOrderId);

            txtOrderId = new TextBox()
            {
                Location = new Point(120, 20),
                Size = new Size(200, 30),
                Font = new Font("Segoe UI", 12),
                BorderStyle = BorderStyle.FixedSingle
            };
            filterPanel.Controls.Add(txtOrderId);

            // Payment Status Label and ComboBox
            Label lblStatus = new Label()
            {
                Text = "Payment Status:",
                Location = new Point(400, 20),
                Size = new Size(150, 30),
                Font = new Font("Segoe UI", 12)
            };
            filterPanel.Controls.Add(lblStatus);

            cmbStatus = new ComboBox()
            {
                Location = new Point(560, 20),
                Size = new Size(200, 30),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 12),
                FlatStyle = FlatStyle.Flat
            };
            cmbStatus.Items.AddRange(new string[] { "All", "Pending", "Completed" });
            cmbStatus.SelectedIndex = 0; // Default to "All"
            filterPanel.Controls.Add(cmbStatus);

            // Search Button with Hover Effect
            btnSearch = CreateRoundedButton("Search", 320, 80, Color.Teal, BtnSearch_Click);
            btnSearch.MouseEnter += (s, e) => btnSearch.BackColor = Color.DarkCyan;
            btnSearch.MouseLeave += (s, e) => btnSearch.BackColor = Color.Teal;
            filterPanel.Controls.Add(btnSearch);

            // DataGridView for displaying search results
            dgvDisplay = new DataGridView()
            {
                Location = new Point(50, 250),
                Size = new Size(800, 400),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Font = new Font("Segoe UI", 12),
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                BorderStyle = BorderStyle.FixedSingle,
                BackgroundColor = Color.White
            };

            // Styling DataGridView headers and rows
            dgvDisplay.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            dgvDisplay.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            dgvDisplay.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgvDisplay.DefaultCellStyle.SelectionBackColor = Color.LightSkyBlue;
            dgvDisplay.DefaultCellStyle.SelectionForeColor = Color.Black;
            dgvDisplay.AlternatingRowsDefaultCellStyle.BackColor = Color.AliceBlue;
            Controls.Add(dgvDisplay);

            // Logout Button with Rounded Style
            btnLogout = CreateRoundedButton("Logout", 700, 670, Color.Crimson, BtnLogout_Click);
            btnLogout.MouseEnter += (s, e) => btnLogout.BackColor = Color.DarkRed;
            btnLogout.MouseLeave += (s, e) => btnLogout.BackColor = Color.Crimson;
            Controls.Add(btnLogout);
        }



        private Button CreateRoundedButton(string text, int x, int y, Color color, EventHandler onClick)
        {
            Button button = new Button()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(200, 40),
                BackColor = color,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.White
            };
            button.FlatAppearance.BorderSize = 0;
            button.Paint += (s, e) =>
            {
                Rectangle rect = button.ClientRectangle;
                GraphicsPath path = new GraphicsPath();
                path.AddEllipse(-10, -10, rect.Width + 20, rect.Height + 20);
                button.Region = new Region(path);
            };
            button.Click += onClick;
            return button;
        }

        // Event handler for "Search Payments" button
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            string orderId = txtOrderId.Text;
            string status = cmbStatus.SelectedItem.ToString();

            // Validate inputs
            if (!string.IsNullOrEmpty(orderId) && !int.TryParse(orderId, out _))
            {
                MessageBox.Show("Order ID must be numeric.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Load payment records
            LoadPayments(orderId, status);
        }

        // Method to load payments from the database based on filters
        private void LoadPayments(string orderId, string status)
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";

            try
            {
                using (OracleConnection connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    // Base query
                    string query = "SELECT PaymentId, OrderId, PaymentAmount, PaymentDate, PaymentStatus FROM Payment WHERE 1=1";

                    // Add filters
                    if (!string.IsNullOrEmpty(orderId))
                        query += " AND OrderId = :OrderId";
                    if (status != "All")
                        query += " AND PaymentStatus = :PaymentStatus";

                    using (OracleCommand command = new OracleCommand(query, connection))
                    {
                        if (!string.IsNullOrEmpty(orderId))
                            command.Parameters.Add(new OracleParameter("OrderId", orderId));
                        if (status != "All")
                            command.Parameters.Add(new OracleParameter("PaymentStatus", status));

                        OracleDataAdapter adapter = new OracleDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dgvDisplay.DataSource = dataTable;

                        if (dataTable.Rows.Count == 0)
                        {
                            MessageBox.Show("No payments found matching the criteria.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading payments: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Logout button event handler
        private void BtnLogout_Click(object sender, EventArgs e)
        {
            // Close current form
            this.Close();

            // Open login form
            Form10 loginForm = new Form10();
            loginForm.Show();
        }
    }
}
