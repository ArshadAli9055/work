﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public partial class DeliveryForm : Form
    {
        private DataGridView dgvOrders;
        private TextBox txtSearch;
        private Button btnSearch;
        private Button btnUpdateStatus;
        private StatusStrip statusStrip;
        private ToolStripStatusLabel lblStatus;
        private Button btnLogout;

        public DeliveryForm()
        {
            InitializeForm();
        }

        private void InitializeForm()
        {
            // Form settings
            this.Text = "Delivery Personnel Dashboard";
            this.Size = new Size(1000, 650);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Welcome Label
            Label lblWelcome = new Label()
            {
                Text = "Welcome, Delivery Personnel!",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(370, 20),
                AutoSize = true
            };
            Controls.Add(lblWelcome);

            // Search Section
            Label lblSearch = new Label()
            {
                Text = "Search Order ID:",
                Location = new Point(50, 80),
                Size = new Size(120, 25)
            };
            Controls.Add(lblSearch);

            txtSearch = new TextBox()
            {
                Location = new Point(180, 80),
                Size = new Size(250, 30),
                Font = new Font("Arial", 12),
                PlaceholderText = "Enter Order ID..."
            };
            Controls.Add(txtSearch);

            btnSearch = new Button()
            {
                Text = "Search",
                Location = new Point(450, 80),
                Size = new Size(120, 30),
                BackColor = Color.LightSkyBlue,
                Font = new Font("Arial", 12)
            };
            btnSearch.Click += BtnSearch_Click; // Event handler
            Controls.Add(btnSearch);

            // Update Status Button
            btnUpdateStatus = new Button()
            {
                Text = "Update Status",
                Location = new Point(580, 80),
                Size = new Size(150, 30),
                BackColor = Color.LightGreen,
                Font = new Font("Arial", 12)
            };
            btnUpdateStatus.Click += BtnUpdateStatus_Click; // Event handler
            Controls.Add(btnUpdateStatus);

            // DataGridView to display order data
            dgvOrders = new DataGridView()
            {
                Location = new Point(50, 150),
                Size = new Size(900, 350),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };
            dgvOrders.CellFormatting += DgvOrders_CellFormatting;
            Controls.Add(dgvOrders);

            // Status Bar
            statusStrip = new StatusStrip();
            lblStatus = new ToolStripStatusLabel("Ready...");
            statusStrip.Items.Add(lblStatus);
            Controls.Add(statusStrip);

            // Logout Button
            btnLogout = new Button()
            {
                Text = "Logout",
                Location = new Point(300, 520),
                Size = new Size(200, 40),
                BackColor = Color.LightCoral,
                Font = new Font("Arial", 12)
            };
            btnLogout.Click += BtnLogout_Click;
            Controls.Add(btnLogout);

            // Load default order data
            LoadOrderData("");
        }

        private void DgvOrders_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            // Change row color based on order status
            if (dgvOrders.Columns[e.ColumnIndex].Name == "Status" && e.Value != null)
            {
                string status = e.Value.ToString();
                if (status == "Delivered")
                {
                    e.CellStyle.BackColor = Color.LightGreen;
                }
                else if (status == "Pending")
                {
                    e.CellStyle.BackColor = Color.Yellow;
                }
                else
                {
                    e.CellStyle.BackColor = Color.LightGray;
                }
            }
        }

        // Event handler for Search Button
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            string searchQuery = txtSearch.Text.Trim();
            LoadOrderData(searchQuery);
        }

        // Event handler for Update Status Button
        private void BtnUpdateStatus_Click(object sender, EventArgs e)
        {
            if (dgvOrders.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvOrders.SelectedRows[0];
                int orderTrackId = Convert.ToInt32(selectedRow.Cells["OrderTrackingId"].Value);

                // Prompt for new status
                string newStatus = PromptForStatus();
                if (!string.IsNullOrEmpty(newStatus))
                {
                    UpdateOrderStatus(orderTrackId, newStatus);
                    LoadOrderData(""); // Reload data
                }
            }
            else
            {
                MessageBox.Show("Please select an order to update.", "Update Status", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private string PromptForStatus()
        {
            using (Form prompt = new Form())
            {
                prompt.Text = "Update Status";
                prompt.Size = new Size(300, 200);

                Label lblStatus = new Label()
                {
                    Text = "Enter new status:",
                    Location = new Point(20, 20),
                    AutoSize = true
                };
                prompt.Controls.Add(lblStatus);

                TextBox txtStatus = new TextBox()
                {
                    Location = new Point(20, 50),
                    Width = 240
                };
                prompt.Controls.Add(txtStatus);

                Button btnConfirm = new Button()
                {
                    Text = "Confirm",
                    Location = new Point(80, 100),
                    DialogResult = DialogResult.OK
                };
                prompt.Controls.Add(btnConfirm);

                if (prompt.ShowDialog() == DialogResult.OK)
                {
                    return txtStatus.Text.Trim();
                }
                return null;
            }
        }

        private void LoadOrderData(string searchQuery)
        {
            lblStatus.Text = "Loading data...";
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";

            try
            {
                using (OracleConnection connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT OrderTrackingId, OrderId, Status, UpdatedDate FROM OrderTrack";
                    if (!string.IsNullOrEmpty(searchQuery))
                    {
                        query += " WHERE OrderId = :SearchQuery";
                    }

                    using (OracleCommand command = new OracleCommand(query, connection))
                    {
                        if (!string.IsNullOrEmpty(searchQuery))
                        {
                            command.Parameters.Add(new OracleParameter("SearchQuery", searchQuery));
                        }

                        OracleDataAdapter adapter = new OracleDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dgvOrders.DataSource = dataTable;
                        lblStatus.Text = "Data loaded successfully";

                        // Inform if no records found
                        if (dataTable.Rows.Count == 0)
                        {
                            MessageBox.Show("No records found for the given Order ID.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Error loading data";
                MessageBox.Show("Error loading order data: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateOrderStatus(int orderTrackId, string newStatus)
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";

            try
            {
                using (OracleConnection connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    string query = "UPDATE OrderTrack SET Status = :NewStatus, UpdatedDate = SYSDATE WHERE OrderTrackingId = :OrderTrackId";

                    using (OracleCommand command = new OracleCommand(query, connection))
                    {
                        command.Parameters.Add(new OracleParameter("NewStatus", newStatus));
                        command.Parameters.Add(new OracleParameter("OrderTrackingId", orderTrackId));

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Order status updated successfully.", "Update Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Failed to update order status. Please try again.", "Update Status", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating order status: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            // Close the current ManagerForm
            this.Close();

            // Navigate to the Login form
            Form10 loginForm = new Form10();
            loginForm.Show();
        }
    }
}
