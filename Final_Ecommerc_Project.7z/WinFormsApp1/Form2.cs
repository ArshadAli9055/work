﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client; 

namespace WinFormsApp1
{
    public partial class Form2 : Form
    {
        // UI Controls
        private TextBox txtProductId, txtProductName, txtSupplierId, txtUnitPrice, txtStatus;
        private Button btnLoadProducts, btnAddProduct, btnUpdateProduct, btnDeleteProduct;
        private DataGridView dataGridViewProducts;

        // Database connection
        private OracleConnection dbConnection;

        public Form2()
        {
            InitializeComponent();
            InitializeDatabaseConnection(); // Initialize Oracle connection
            InitializeCustomComponents();  // Setup UI components
        }

        private void InitializeDatabaseConnection()
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";
            dbConnection = new OracleConnection(connectionString);
        }

        private void InitializeCustomComponents()
        {
            // Form Properties
            this.Text = "Product Management";
            this.Size = new Size(800, 450);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Title Label
            Label lblTitle = new Label()
            {
                Text = "Product Management",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(250, 10),
                Size = new Size(300, 40),
                TextAlign = ContentAlignment.MiddleCenter
            };
            Controls.Add(lblTitle);

            // Labels and Textboxes
            Controls.Add(CreateLabel("Product ID:", 20, 70));
            Controls.Add(CreateLabel("Name:", 20, 120));
            Controls.Add(CreateLabel("Supplier ID:", 20, 170));
            Controls.Add(CreateLabel("Unit Price:", 20, 220));
            Controls.Add(CreateLabel("Status:", 20, 270));

            txtProductId = CreateTextBox(120, 70);
            txtProductName = CreateTextBox(120, 120);
            txtSupplierId = CreateTextBox(120, 170);
            txtUnitPrice = CreateTextBox(120, 220);
            txtStatus = CreateTextBox(120, 270);

            Controls.AddRange(new Control[] { txtProductId, txtProductName, txtSupplierId, txtUnitPrice, txtStatus });

            // DataGridView
            dataGridViewProducts = new DataGridView()
            {
                Location = new Point(300, 70),
                Size = new Size(470, 250),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            Controls.Add(dataGridViewProducts);

            // Buttons
            btnLoadProducts = CreateButton("Load Products", 300, 340, Color.LightBlue);
            btnAddProduct = CreateButton("Add Product", 420, 340, Color.LightGreen);
            btnUpdateProduct = CreateButton("Update Product", 540, 340, Color.Gold);
            btnDeleteProduct = CreateButton("Delete Product", 660, 340, Color.Salmon);

            // Add buttons to the form
            Controls.AddRange(new Control[] { btnLoadProducts, btnAddProduct, btnUpdateProduct, btnDeleteProduct });

            // Event handlers
            btnLoadProducts.Click += BtnLoadProducts_Click;
            btnAddProduct.Click += BtnAddProduct_Click;
            btnUpdateProduct.Click += BtnUpdateProduct_Click;
            btnDeleteProduct.Click += BtnDeleteProduct_Click;
        }

        // Helper methods to create UI components
        private Label CreateLabel(string text, int x, int y)
        {
            return new Label()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(80, 30)
            };
        }

        private TextBox CreateTextBox(int x, int y)
        {
            return new TextBox()
            {
                Location = new Point(x, y),
                Size = new Size(150, 25)
            };
        }

        private Button CreateButton(string text, int x, int y, Color color)
        {
            return new Button()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(100, 40),
                BackColor = color,
                FlatStyle = FlatStyle.Flat
            };
        }

        // Event handlers for button actions
        private void BtnLoadProducts_Click(object sender, EventArgs e)
        {
            LoadProducts();
        }

        private void BtnAddProduct_Click(object sender, EventArgs e)
        {
            AddProduct();
        }

        private void BtnUpdateProduct_Click(object sender, EventArgs e)
        {
            UpdateProduct();
        }

        private void BtnDeleteProduct_Click(object sender, EventArgs e)
        {
            DeleteProduct();
        }

        // Database actions
        private void LoadProducts()
        {
            try
            {
                string query = "SELECT * FROM Product ORDER BY ProductId";
                OracleDataAdapter adapter = new OracleDataAdapter(query, dbConnection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridViewProducts.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading products: {ex.Message}");
            }
        }

        private void AddProduct()
        {
            try
            {
                string query = "INSERT INTO Product (ProductId, ProductName, SupplierId, UnitPrice, Status) " +
                               "VALUES (:ProductId, :ProductName, :SupplierId, :UnitPrice, :Status)";
                OracleCommand cmd = new OracleCommand(query, dbConnection);
                cmd.Parameters.Add(":ProductId", OracleDbType.Int32).Value = Convert.ToInt32(txtProductId.Text);
                cmd.Parameters.Add(":ProductName", OracleDbType.Varchar2).Value = txtProductName.Text;
                cmd.Parameters.Add(":SupplierId", OracleDbType.Int32).Value = Convert.ToInt32(txtSupplierId.Text);
                cmd.Parameters.Add(":UnitPrice", OracleDbType.Decimal).Value = Convert.ToDecimal(txtUnitPrice.Text);
                cmd.Parameters.Add(":Status", OracleDbType.Varchar2).Value = txtStatus.Text;

                dbConnection.Open();
                cmd.ExecuteNonQuery();
                dbConnection.Close();

                MessageBox.Show("Product added successfully.");
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding product: {ex.Message}");
                dbConnection.Close();
            }
        }

        private void UpdateProduct()
        {
            try
            {
                string query = "UPDATE Product SET ProductName = :ProductName, SupplierId = :SupplierId, " +
                               "UnitPrice = :UnitPrice, Status = :Status WHERE ProductId = :ProductId";
                OracleCommand cmd = new OracleCommand(query, dbConnection);
                cmd.Parameters.Add(":ProductName", OracleDbType.Varchar2).Value = txtProductName.Text;
                cmd.Parameters.Add(":SupplierId", OracleDbType.Int32).Value = Convert.ToInt32(txtSupplierId.Text);
                cmd.Parameters.Add(":UnitPrice", OracleDbType.Decimal).Value = Convert.ToDecimal(txtUnitPrice.Text);
                cmd.Parameters.Add(":Status", OracleDbType.Varchar2).Value = txtStatus.Text;
                cmd.Parameters.Add(":ProductId", OracleDbType.Int32).Value = Convert.ToInt32(txtProductId.Text);

                dbConnection.Open();
                cmd.ExecuteNonQuery();
                dbConnection.Close();

                MessageBox.Show("Product updated successfully.");
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating product: {ex.Message}");
                dbConnection.Close();
            }
        }

        private void DeleteProduct()
        {
            try
            {
                string query = "DELETE FROM Product WHERE ProductId = :ProductId";
                OracleCommand cmd = new OracleCommand(query, dbConnection);
                cmd.Parameters.Add(":ProductId", OracleDbType.Int32).Value = Convert.ToInt32(txtProductId.Text);

                dbConnection.Open();
                cmd.ExecuteNonQuery();
                dbConnection.Close();

                MessageBox.Show("Product deleted successfully.");
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting product: {ex.Message}");
                dbConnection.Close();
            }
        }
    }
}
