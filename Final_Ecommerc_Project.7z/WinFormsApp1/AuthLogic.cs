﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;
public static class AuthLogic
{
    public static string Authenticate(string username, string password)
    {
        string role = null;

        using (OracleConnection connection = new OracleConnection("User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE"))
        {
            try
            {
                connection.Open();
                string query = "SELECT role FROM Users WHERE username = :username AND password = :password";
                using (OracleCommand command = new OracleCommand(query, connection))
                {
                    command.Parameters.Add(new OracleParameter("username", username));
                    command.Parameters.Add(new OracleParameter("password", password));

                    using (OracleDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            role = reader["role"].ToString().ToLower(); // Normalize role
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database error: " + ex.Message);
            }
        }

        return role; // Returns null if no match is found
    }
}
