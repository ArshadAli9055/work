﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form10 : Form
    {
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnLogin;
        private Label lblMessage;

        public Form10()
        {
            InitializeComponent();
            InitializeLoginForm();
        }

        private void InitializeLoginForm()
        {
            // Form settings
            this.Text = "Login";
            this.Size = new Size(450, 400);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(245, 245, 245); // Light gray background

            // Title Label
            Label lblTitle = new Label()
            {
                Text = "Welcome! Please Log In",
                Font = new Font("Arial", 20, FontStyle.Bold),
                Location = new Point(70, 30),
                Size = new Size(300, 40),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.FromArgb(0, 102, 204) // Blue color
            };
            Controls.Add(lblTitle);

            // Panel for form controls
            Panel formPanel = new Panel()
            {
                Location = new Point(50, 80),
                Size = new Size(350, 220),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            Controls.Add(formPanel);

            // Username Label and TextBox
            formPanel.Controls.Add(CreateLabel("Username:", 30, 30));
            txtUsername = CreateTextBox(120, 30);
            txtUsername.PlaceholderText = "Enter your username"; // Placeholder for modern UI
            formPanel.Controls.Add(txtUsername);

            // Password Label and TextBox
            formPanel.Controls.Add(CreateLabel("Password:", 30, 80));
            txtPassword = CreateTextBox(120, 80);
            txtPassword.PlaceholderText = "Enter your password";
            txtPassword.PasswordChar = '*'; // Mask the password
            formPanel.Controls.Add(txtPassword);

            // Login Button
            btnLogin = new Button()
            {
                Text = "Login",
                Location = new Point(120, 130),
                Size = new Size(100, 40),
                BackColor = Color.FromArgb(0, 153, 51), // Green
                ForeColor = Color.White,
                Font = new Font("Arial", 12),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.MouseEnter += (s, e) => btnLogin.BackColor = Color.FromArgb(0, 204, 51); // Lighter green on hover
            btnLogin.MouseLeave += (s, e) => btnLogin.BackColor = Color.FromArgb(0, 153, 51);
            btnLogin.Click += BtnLogin_Click;
            formPanel.Controls.Add(btnLogin);

            // Message Label for feedback
            lblMessage = new Label()
            {
                Text = "",
                Location = new Point(30, 180),
                Size = new Size(300, 30),
                ForeColor = Color.Red,
                Font = new Font("Arial", 10, FontStyle.Italic),
                TextAlign = ContentAlignment.MiddleCenter
            };
            formPanel.Controls.Add(lblMessage);

            // Footer Label
            Label lblFooter = new Label()
            {
                Text = "© 2024 Your Company",
                Font = new Font("Arial", 8),
                Location = new Point(150, 350),
                AutoSize = true,
                ForeColor = Color.Gray
            };
            Controls.Add(lblFooter);

            // Tooltips for better user experience
            ToolTip toolTip = new ToolTip();
            toolTip.SetToolTip(txtUsername, "Enter your username.");
            toolTip.SetToolTip(txtPassword, "Enter your password.");
            toolTip.SetToolTip(btnLogin, "Click to login with your credentials.");
        }

        // CreateLabel helper function
        private Label CreateLabel(string text, int x, int y)
        {
            return new Label()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(80, 30),
                Font = new Font("Arial", 12),
                ForeColor = Color.Black
            };
        }

        // CreateTextBox helper function
        private TextBox CreateTextBox(int x, int y)
        {
            return new TextBox()
            {
                Location = new Point(x, y),
                Size = new Size(200, 25),
                Font = new Font("Arial", 12),
                BackColor = Color.FromArgb(250, 250, 250), // Light background for textbox
                BorderStyle = BorderStyle.FixedSingle
            };
        }


        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                lblMessage.Text = "Please enter both username and password.";
                lblMessage.ForeColor = Color.Red;
                return;
            }

            // Authenticate user
            string role = AuthLogic.Authenticate(username, password);
            if (role != null)
            {
                lblMessage.ForeColor = Color.Green;
                lblMessage.Text = $"Login successful! Role: {role}";
                MessageBox.Show($"Login successful! Role: {role}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                OpenRoleSpecificForm(role);
            }
            else
            {
                lblMessage.ForeColor = Color.Red;
                lblMessage.Text = "Invalid username or password.";
            }
        }

        private void OpenRoleSpecificForm(string role)
        {
            Form nextForm;
            switch (role.ToLower())
            {
                case "customer":
                    nextForm = new CustomerForm();
                    break;
                case "manager":
                    nextForm = new ManagerForm();
                    break;
                case "cashier":
                    nextForm = new CashierForm();
                    break;
                case "inventorystaff":
                    nextForm = new InventoryStaffForm();
                    break;
                case "delivery":
                    nextForm = new DeliveryForm();
                    break;
                case "admin":
                    nextForm = new AdminForm();
                    break;
                default:
                    MessageBox.Show("Unknown role. Contact administrator.");
                    return;
            }

            // Show the role-specific form and hide the login form
            nextForm.Show();
            this.Hide();
        }
    }
}
