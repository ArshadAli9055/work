using System;
using System.Data;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private DatabaseConnection dbConnection;
        private TextBox txtUserId, txtUsername, txtPassword, txtContact, txtRole, txtName;
        private Button btnLoadUsers, btnAddUser, btnUpdateUser, btnDeleteUser;
        private DataGridView dataGridViewUsers;
        private Label lblTitle, lblUserId, lblUsername, lblPassword, lblContact, lblRole, lblName;

        public Form1()
        {
            InitializeComponent();
            dbConnection = new DatabaseConnection();

            // Initialize controls
            InitializeControls();
        }

        private void InitializeControls()
        {
            this.txtUserId = new TextBox();
            this.txtUsername = new TextBox();
            this.txtPassword = new TextBox();
            this.txtContact = new TextBox();
            this.txtRole = new TextBox();
            this.txtName = new TextBox();
            this.btnLoadUsers = new Button();
            this.btnAddUser = new Button();
            this.btnUpdateUser = new Button();
            this.btnDeleteUser = new Button();
            this.dataGridViewUsers = new DataGridView();
            this.lblTitle = new Label();
            this.lblUserId = new Label();
            this.lblUsername = new Label();
            this.lblPassword = new Label();
            this.lblContact = new Label();
            this.lblRole = new Label();
            this.lblName = new Label();

            // Title Label
            this.lblTitle.Text = "User Management";
            this.lblTitle.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(20, 10);
            this.lblTitle.Size = new System.Drawing.Size(300, 30);

            // Labels
            this.lblUserId.Text = "User ID:";
            this.lblUserId.Location = new System.Drawing.Point(20, 50);
            this.lblUsername.Text = "Username:";
            this.lblUsername.Location = new System.Drawing.Point(20, 90);
            this.lblPassword.Text = "Password:";
            this.lblPassword.Location = new System.Drawing.Point(20, 130);
            this.lblContact.Text = "Contact:";
            this.lblContact.Location = new System.Drawing.Point(20, 170);
            this.lblRole.Text = "Role:";
            this.lblRole.Location = new System.Drawing.Point(20, 210);
            this.lblName.Text = "Name:";
            this.lblName.Location = new System.Drawing.Point(20, 250);

            // Textboxes
            this.txtUserId.Location = new System.Drawing.Point(120, 50);
            this.txtUsername.Location = new System.Drawing.Point(120, 90);
            this.txtPassword.Location = new System.Drawing.Point(120, 130);
            this.txtContact.Location = new System.Drawing.Point(120, 170);
            this.txtRole.Location = new System.Drawing.Point(120, 210);
            this.txtName.Location = new System.Drawing.Point(120, 250);

            // DataGridView
            this.dataGridViewUsers.Location = new System.Drawing.Point(250, 50);
            this.dataGridViewUsers.Size = new System.Drawing.Size(500, 200);
            this.dataGridViewUsers.SelectionChanged += new EventHandler(this.dataGridViewUsers_SelectionChanged);

            // Buttons
            this.btnLoadUsers.Text = "Load Users";
            this.btnLoadUsers.Location = new System.Drawing.Point(3, 300);
            this.btnAddUser.Text = "Add User";
            this.btnAddUser.Location = new System.Drawing.Point(120, 300);
            this.btnUpdateUser.Text = "Update User";
            this.btnUpdateUser.Location = new System.Drawing.Point(220, 300);
            this.btnDeleteUser.Text = "Delete User";
            this.btnDeleteUser.Location = new System.Drawing.Point(320, 300);

            // Add controls to the form
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblUserId);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.lblContact);
            this.Controls.Add(this.lblRole);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtUserId);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.txtRole);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.btnLoadUsers);
            this.Controls.Add(this.btnAddUser);
            this.Controls.Add(this.btnUpdateUser);
            this.Controls.Add(this.btnDeleteUser);
            this.Controls.Add(this.dataGridViewUsers);

            // Set initial button states
            this.btnUpdateUser.Enabled = false;
            this.btnDeleteUser.Enabled = false;

            // Event handlers
            this.btnLoadUsers.Click += new EventHandler(this.btnLoadUsers_Click);
            this.btnAddUser.Click += new EventHandler(this.btnAddUser_Click);
            this.btnUpdateUser.Click += new EventHandler(this.btnUpdateUser_Click);
            this.btnDeleteUser.Click += new EventHandler(this.btnDeleteUser_Click);

            // Form properties
            this.ClientSize = new System.Drawing.Size(800, 400);
            this.Text = "User Management";
        }

        private void LoadUsers()
        {
            try
            {
                // The SELECT query to retrieve users
                string query = "SELECT * FROM Users ORDER BY UserId";
                DataTable usersTable = dbConnection.ExecuteQuery(query); // Calling the ExecuteQuery method
                dataGridViewUsers.DataSource = usersTable;

                // Disable the Update and Delete buttons if no row is selected
                btnUpdateUser.Enabled = false;
                btnDeleteUser.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading users: {ex.Message}");
            }
        }

        private void btnLoadUsers_Click(object sender, EventArgs e)
        {
            LoadUsers();
        }

        private void dataGridViewUsers_SelectionChanged(object sender, EventArgs e)
        {
            // Enable/Disable the Update/Delete buttons based on row selection
            if (dataGridViewUsers.SelectedRows.Count > 0)
            {
                btnUpdateUser.Enabled = true;
                btnDeleteUser.Enabled = true;
            }
            else
            {
                btnUpdateUser.Enabled = false;
                btnDeleteUser.Enabled = false;
            }
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            try
            {
                // Prepare parameters
                OracleParameter[] parameters = new OracleParameter[]
                {
                    new OracleParameter("p_username", OracleDbType.Varchar2) { Value = txtUsername.Text },
                    new OracleParameter("p_password", OracleDbType.Varchar2) { Value = txtPassword.Text },
                    new OracleParameter("p_contact", OracleDbType.Varchar2) { Value = txtContact.Text },
                    new OracleParameter("p_role", OracleDbType.Varchar2) { Value = txtRole.Text },
                    new OracleParameter("p_name", OracleDbType.Varchar2) { Value = txtName.Text }
                };

                // Call stored procedure for adding user
                int result = dbConnection.ExecuteStoredProcedureNonQuery("SP_ADD_USER", parameters);
                if (result > 0)
                {
                    MessageBox.Show("User added successfully!");
                    LoadUsers();  // Reload user data
                }
                else
                {
                    MessageBox.Show("Failed to add user.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding user: {ex.Message}");
            }
        }

        private void btnUpdateUser_Click(object sender, EventArgs e)
        {
            try
            {
                // Prepare parameters
                OracleParameter[] parameters = new OracleParameter[]
                {
                    new OracleParameter("p_user_id", OracleDbType.Int32) { Value = txtUserId.Text },
                    new OracleParameter("p_username", OracleDbType.Varchar2) { Value = txtUsername.Text },
                    new OracleParameter("p_password", OracleDbType.Varchar2) { Value = txtPassword.Text },
                    new OracleParameter("p_contact", OracleDbType.Varchar2) { Value = txtContact.Text },
                    new OracleParameter("p_role", OracleDbType.Varchar2) { Value = txtRole.Text },
                    new OracleParameter("p_name", OracleDbType.Varchar2) { Value = txtName.Text }
                };

                // Call stored procedure for updating user
                int result = dbConnection.ExecuteStoredProcedureNonQuery("SP_UPDATE_USER", parameters);
                if (result > 0)
                {
                    MessageBox.Show("User updated successfully!");
                    LoadUsers();  // Reload user data
                }
                else
                {
                    MessageBox.Show("Failed to update user.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating user: {ex.Message}");
            }
        }

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the selected user ID from DataGridView
                int userId = Convert.ToInt32(dataGridViewUsers.SelectedRows[0].Cells["UserId"].Value);

                // Prepare parameters
                OracleParameter[] parameters = new OracleParameter[]
                {
                    new OracleParameter("p_user_id", OracleDbType.Int32) { Value = userId }
                };

                // Call stored procedure for deleting user
                int result = dbConnection.ExecuteStoredProcedureNonQuery("SP_DELETE_USER", parameters);
                if (result > 0)
                {
                    MessageBox.Show("User deleted successfully!");
                    LoadUsers();  // Reload user data
                }
                else
                {
                    MessageBox.Show("Failed to delete user.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting user: {ex.Message}");
            }
        }
    }
}
