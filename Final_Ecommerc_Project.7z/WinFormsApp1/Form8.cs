﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public partial class Form8 : Form
    {
        private TextBox txtOrderTrackingId, txtOrderId, txtStatus, txtUpdatedDate;
        private Button btnLoadOrderTracks, btnAddOrderTrack, btnUpdateOrderTrack, btnDeleteOrderTrack;
        private DataGridView dataGridViewOrderTracks;
        private OracleConnection dbConnection;

        public Form8()
        {
            InitializeComponent();
            InitializeDatabaseConnection();
            InitializeCustomComponents();
        }

       
        private void InitializeDatabaseConnection()
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";
            dbConnection = new OracleConnection(connectionString);
        }

     
        private void InitializeCustomComponents()
        {
            
            Label lblTitle = new Label()
            {
                Text = "Order Tracking Management",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(250, 10),
                Size = new Size(400, 40),
                TextAlign = ContentAlignment.MiddleCenter
            };
            Controls.Add(lblTitle);

            Controls.Add(CreateLabel("Order Tracking ID:", 20, 70));
            Controls.Add(CreateLabel("Order ID:", 20, 120));
            Controls.Add(CreateLabel("Status:", 20, 170));
            Controls.Add(CreateLabel("Updated Date (YYYY-MM-DD):", 20, 220));

            txtOrderTrackingId = CreateTextBox(200, 70);
            txtOrderId = CreateTextBox(200, 120);
            txtStatus = CreateTextBox(200, 170);
            txtUpdatedDate = CreateTextBox(200, 220);

            Controls.AddRange(new Control[] { txtOrderTrackingId, txtOrderId, txtStatus, txtUpdatedDate });

            dataGridViewOrderTracks = new DataGridView()
            {
                Location = new Point(420, 70),
                Size = new Size(450, 250),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            Controls.Add(dataGridViewOrderTracks);

            btnLoadOrderTracks = CreateButton("Load Tracks", 420, 340, Color.LightBlue);
            btnAddOrderTrack = CreateButton("Add Track", 540, 340, Color.LightGreen);
            btnUpdateOrderTrack = CreateButton("Update Track", 660, 340, Color.Gold);
            btnDeleteOrderTrack = CreateButton("Delete Track", 780, 340, Color.Salmon);

            Controls.AddRange(new Control[] { btnLoadOrderTracks, btnAddOrderTrack, btnUpdateOrderTrack, btnDeleteOrderTrack });

            btnLoadOrderTracks.Click += BtnLoadOrderTracks_Click;
            btnAddOrderTrack.Click += BtnAddOrderTrack_Click;
            btnUpdateOrderTrack.Click += BtnUpdateOrderTrack_Click;
            btnDeleteOrderTrack.Click += BtnDeleteOrderTrack_Click;
        }

        
        private Label CreateLabel(string text, int x, int y)
        {
            return new Label()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(170, 30)
            };
        }

        private TextBox CreateTextBox(int x, int y)
        {
            return new TextBox()
            {
                Location = new Point(x, y),
                Size = new Size(200, 25)
            };
        }

        private Button CreateButton(string text, int x, int y, Color color)
        {
            return new Button()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(100, 40),
                BackColor = color,
                FlatStyle = FlatStyle.Flat
            };
        }

        
        private void BtnLoadOrderTracks_Click(object sender, EventArgs e)
        {
            LoadOrderTracks();
        }

        private void BtnAddOrderTrack_Click(object sender, EventArgs e)
        {
            AddOrderTrack();
        }

        private void BtnUpdateOrderTrack_Click(object sender, EventArgs e)
        {
            UpdateOrderTrack();
        }

        private void BtnDeleteOrderTrack_Click(object sender, EventArgs e)
        {
            DeleteOrderTrack();
        }

      
        private void LoadOrderTracks()
        {
            try
            {
                string query = "SELECT * FROM OrderTrack ORDER BY OrderTrackingId";
                OracleDataAdapter adapter = new OracleDataAdapter(query, dbConnection);
                DataTable orderTracksTable = new DataTable();
                adapter.Fill(orderTracksTable);
                dataGridViewOrderTracks.DataSource = orderTracksTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading order tracks: {ex.Message}");
            }
        }

        private void AddOrderTrack()
        {
            try
            {
                string query = "INSERT INTO OrderTrack (OrderTrackingId, OrderId, Status, UpdatedDate) " +
                               "VALUES (:OrderTrackingId, :OrderId, :Status, TO_DATE(:UpdatedDate, 'YYYY-MM-DD'))";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("OrderTrackingId", OracleDbType.Int32).Value = int.Parse(txtOrderTrackingId.Text);
                    cmd.Parameters.Add("OrderId", OracleDbType.Int32).Value = int.Parse(txtOrderId.Text);
                    cmd.Parameters.Add("Status", OracleDbType.Varchar2).Value = txtStatus.Text;
                    cmd.Parameters.Add("UpdatedDate", OracleDbType.Varchar2).Value = txtUpdatedDate.Text;

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Order tracking added successfully.");
                    LoadOrderTracks();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding order tracking: {ex.Message}");
            }
        }

        private void UpdateOrderTrack()
        {
            try
            {
                string query = "UPDATE OrderTrack SET OrderId = :OrderId, Status = :Status, " +
                               "UpdatedDate = TO_DATE(:UpdatedDate, 'YYYY-MM-DD') WHERE OrderTrackingId = :OrderTrackingId";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("OrderId", OracleDbType.Int32).Value = int.Parse(txtOrderId.Text);
                    cmd.Parameters.Add("Status", OracleDbType.Varchar2).Value = txtStatus.Text;
                    cmd.Parameters.Add("UpdatedDate", OracleDbType.Varchar2).Value = txtUpdatedDate.Text;
                    cmd.Parameters.Add("OrderTrackingId", OracleDbType.Int32).Value = int.Parse(txtOrderTrackingId.Text);

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Order tracking updated successfully.");
                    LoadOrderTracks();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating order tracking: {ex.Message}");
            }
        }

        private void DeleteOrderTrack()
        {
            try
            {
                string query = "DELETE FROM OrderTrack WHERE OrderTrackingId = :OrderTrackingId";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("OrderTrackingId", OracleDbType.Int32).Value = int.Parse(txtOrderTrackingId.Text);

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Order tracking deleted successfully.");
                    LoadOrderTracks();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting order tracking: {ex.Message}");
            }
        }
    }
}
