﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public partial class Form4 : Form
    {
        private TextBox txtOrderId, txtOrderDate, txtOrderNumber, txtCustomerId, txtTotalAmount, txtStatus;
        private Button btnLoadOrders, btnAddOrder, btnUpdateOrder, btnDeleteOrder;
        private DataGridView dataGridViewOrders;
        private OracleConnection dbConnection;

        public Form4()
        {
            InitializeComponent();
            InitializeDatabaseConnection();
            InitializeCustomComponents();
        }

        // Initialize Database Connection
        private void InitializeDatabaseConnection()
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";
            dbConnection = new OracleConnection(connectionString);
        }

        // Initialize Custom Components
        private void InitializeCustomComponents()
        {
            // Title Label
            Label lblTitle = new Label()
            {
                Text = "Product Orders Management",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(250, 10),
                Size = new Size(400, 40),
                TextAlign = ContentAlignment.MiddleCenter
            };
            Controls.Add(lblTitle);

            // Labels and Textboxes
            Controls.Add(CreateLabel("Order ID:", 20, 70));
            Controls.Add(CreateLabel("Order Date (YYYY-MM-DD):", 20, 120));
            Controls.Add(CreateLabel("Order Number:", 20, 170));
            Controls.Add(CreateLabel("Customer ID:", 20, 220));
            Controls.Add(CreateLabel("Total Amount:", 20, 270));
            Controls.Add(CreateLabel("Status:", 20, 320));

            txtOrderId = CreateTextBox(200, 70);
            txtOrderDate = CreateTextBox(200, 120);
            txtOrderNumber = CreateTextBox(200, 170);
            txtCustomerId = CreateTextBox(200, 220);
            txtTotalAmount = CreateTextBox(200, 270);
            txtStatus = CreateTextBox(200, 320);

            Controls.AddRange(new Control[] { txtOrderId, txtOrderDate, txtOrderNumber, txtCustomerId, txtTotalAmount, txtStatus });

            // DataGridView
            dataGridViewOrders = new DataGridView()
            {
                Location = new Point(420, 70),
                Size = new Size(550, 300),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            Controls.Add(dataGridViewOrders);

            // Buttons
            btnLoadOrders = CreateButton("Load Orders", 420, 400, Color.LightBlue);
            btnAddOrder = CreateButton("Add Order", 540, 400, Color.LightGreen);
            btnUpdateOrder = CreateButton("Update Order", 660, 400, Color.Gold);
            btnDeleteOrder = CreateButton("Delete Order", 780, 400, Color.Salmon);

            Controls.AddRange(new Control[] { btnLoadOrders, btnAddOrder, btnUpdateOrder, btnDeleteOrder });

            // Event Handlers
            btnLoadOrders.Click += BtnLoadOrders_Click;
            btnAddOrder.Click += BtnAddOrder_Click;
            btnUpdateOrder.Click += BtnUpdateOrder_Click;
            btnDeleteOrder.Click += BtnDeleteOrder_Click;
        }

        // Helper Methods to Create UI Components
        private Label CreateLabel(string text, int x, int y)
        {
            return new Label()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(170, 30)
            };
        }

        private TextBox CreateTextBox(int x, int y)
        {
            return new TextBox()
            {
                Location = new Point(x, y),
                Size = new Size(200, 25)
            };
        }

        private Button CreateButton(string text, int x, int y, Color color)
        {
            return new Button()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(100, 40),
                BackColor = color,
                FlatStyle = FlatStyle.Flat
            };
        }

        // Event Handlers for Buttons
        private void BtnLoadOrders_Click(object sender, EventArgs e)
        {
            LoadOrders();
        }

        private void BtnAddOrder_Click(object sender, EventArgs e)
        {
            AddOrder();
        }

        private void BtnUpdateOrder_Click(object sender, EventArgs e)
        {
            UpdateOrder();
        }

        private void BtnDeleteOrder_Click(object sender, EventArgs e)
        {
            DeleteOrder();
        }

        // Database Methods
        private void LoadOrders()
        {
            try
            {
                string query = "SELECT * FROM ProductOrdered ORDER BY OrderId";
                OracleDataAdapter adapter = new OracleDataAdapter(query, dbConnection);
                DataTable ordersTable = new DataTable();
                adapter.Fill(ordersTable);
                dataGridViewOrders.DataSource = ordersTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading orders: {ex.Message}");
            }
        }

        private void AddOrder()
        {
            try
            {
                string query = $"INSERT INTO ProductOrdered (OrderId, OrderDate, OrderNumber, CustomerId, TotalAmount, Status) " +
                               $"VALUES (:OrderId, TO_DATE(:OrderDate, 'YYYY-MM-DD'), :OrderNumber, :CustomerId, :TotalAmount, :Status)";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("OrderId", OracleDbType.Int32).Value = int.Parse(txtOrderId.Text);
                    cmd.Parameters.Add("OrderDate", OracleDbType.Varchar2).Value = txtOrderDate.Text;
                    cmd.Parameters.Add("OrderNumber", OracleDbType.Varchar2).Value = txtOrderNumber.Text;
                    cmd.Parameters.Add("CustomerId", OracleDbType.Int32).Value = int.Parse(txtCustomerId.Text);
                    cmd.Parameters.Add("TotalAmount", OracleDbType.Decimal).Value = decimal.Parse(txtTotalAmount.Text);
                    cmd.Parameters.Add("Status", OracleDbType.Varchar2).Value = txtStatus.Text;

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Order added successfully.");
                    LoadOrders();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding order: {ex.Message}");
            }
        }

        private void UpdateOrder()
        {
            try
            {
                string query = $"UPDATE ProductOrdered SET OrderDate = TO_DATE(:OrderDate, 'YYYY-MM-DD'), " +
                               $"OrderNumber = :OrderNumber, CustomerId = :CustomerId, " +
                               $"TotalAmount = :TotalAmount, Status = :Status WHERE OrderId = :OrderId";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("OrderDate", OracleDbType.Varchar2).Value = txtOrderDate.Text;
                    cmd.Parameters.Add("OrderNumber", OracleDbType.Varchar2).Value = txtOrderNumber.Text;
                    cmd.Parameters.Add("CustomerId", OracleDbType.Int32).Value = int.Parse(txtCustomerId.Text);
                    cmd.Parameters.Add("TotalAmount", OracleDbType.Decimal).Value = decimal.Parse(txtTotalAmount.Text);
                    cmd.Parameters.Add("Status", OracleDbType.Varchar2).Value = txtStatus.Text;
                    cmd.Parameters.Add("OrderId", OracleDbType.Int32).Value = int.Parse(txtOrderId.Text);

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Order updated successfully.");
                    LoadOrders();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating order: {ex.Message}");
            }
        }

        private void DeleteOrder()
        {
            try
            {
                string query = $"DELETE FROM ProductOrdered WHERE OrderId = :OrderId";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("OrderId", OracleDbType.Int32).Value = int.Parse(txtOrderId.Text);

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Order deleted successfully.");
                    LoadOrders();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting order: {ex.Message}");
            }
        }
    }
}
