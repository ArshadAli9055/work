﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public partial class Form6 : Form
    {
        private TextBox txtPaymentId, txtOrderId, txtPaymentAmount, txtPaymentDate, txtPaymentStatus;
        private Button btnLoadPayments, btnAddPayment, btnUpdatePayment, btnDeletePayment;
        private DataGridView dataGridViewPayments;
        private OracleConnection dbConnection;

        public Form6()
        {
            InitializeComponent();
            InitializeDatabaseConnection();
            InitializeCustomComponents();
        }

        // Initialize Database Connection
        private void InitializeDatabaseConnection()
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";
            dbConnection = new OracleConnection(connectionString);
        }

        // Initialize Custom Components
        private void InitializeCustomComponents()
        {
            // Title Label
            Label lblTitle = new Label()
            {
                Text = "Payment Management",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(250, 10),
                Size = new Size(400, 40),
                TextAlign = ContentAlignment.MiddleCenter
            };
            Controls.Add(lblTitle);

            // Labels and Textboxes
            Controls.Add(CreateLabel("Payment ID:", 20, 70));
            Controls.Add(CreateLabel("Order ID:", 20, 120));
            Controls.Add(CreateLabel("Payment Amount:", 20, 170));
            Controls.Add(CreateLabel("Payment Date (YYYY-MM-DD):", 20, 220));
            Controls.Add(CreateLabel("Payment Status:", 20, 270));

            txtPaymentId = CreateTextBox(200, 70);
            txtOrderId = CreateTextBox(200, 120);
            txtPaymentAmount = CreateTextBox(200, 170);
            txtPaymentDate = CreateTextBox(200, 220);
            txtPaymentStatus = CreateTextBox(200, 270);

            Controls.AddRange(new Control[] { txtPaymentId, txtOrderId, txtPaymentAmount, txtPaymentDate, txtPaymentStatus });

            // DataGridView
            dataGridViewPayments = new DataGridView()
            {
                Location = new Point(420, 70),
                Size = new Size(450, 250),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            Controls.Add(dataGridViewPayments);

            // Buttons
            btnLoadPayments = CreateButton("Load Payments", 420, 340, Color.LightBlue);
            btnAddPayment = CreateButton("Add Payment", 540, 340, Color.LightGreen);
            btnUpdatePayment = CreateButton("Update Payment", 660, 340, Color.Gold);
            btnDeletePayment = CreateButton("Delete Payment", 780, 340, Color.Salmon);

            Controls.AddRange(new Control[] { btnLoadPayments, btnAddPayment, btnUpdatePayment, btnDeletePayment });

            // Event Handlers
            btnLoadPayments.Click += BtnLoadPayments_Click;
            btnAddPayment.Click += BtnAddPayment_Click;
            btnUpdatePayment.Click += BtnUpdatePayment_Click;
            btnDeletePayment.Click += BtnDeletePayment_Click;
        }

        // Helper Methods to Create UI Components
        private Label CreateLabel(string text, int x, int y)
        {
            return new Label()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(170, 30)
            };
        }

        private TextBox CreateTextBox(int x, int y)
        {
            return new TextBox()
            {
                Location = new Point(x, y),
                Size = new Size(200, 25)
            };
        }

        private Button CreateButton(string text, int x, int y, Color color)
        {
            return new Button()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(100, 40),
                BackColor = color,
                FlatStyle = FlatStyle.Flat
            };
        }

        // Event Handlers for Buttons
        private void BtnLoadPayments_Click(object sender, EventArgs e)
        {
            LoadPayments();
        }

        private void BtnAddPayment_Click(object sender, EventArgs e)
        {
            AddPayment();
        }

        private void BtnUpdatePayment_Click(object sender, EventArgs e)
        {
            UpdatePayment();
        }

        private void BtnDeletePayment_Click(object sender, EventArgs e)
        {
            DeletePayment();
        }

        // Database Methods
        private void LoadPayments()
        {
            try
            {
                string query = "SELECT * FROM Payment ORDER BY PaymentId";
                OracleDataAdapter adapter = new OracleDataAdapter(query, dbConnection);
                DataTable paymentsTable = new DataTable();
                adapter.Fill(paymentsTable);
                dataGridViewPayments.DataSource = paymentsTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading payments: {ex.Message}");
            }
        }

        private void AddPayment()
        {
            try
            {
                string query = "INSERT INTO Payment (PaymentId, OrderId, PaymentAmount, PaymentDate, PaymentStatus) " +
                               "VALUES (:PaymentId, :OrderId, :PaymentAmount, TO_DATE(:PaymentDate, 'YYYY-MM-DD'), :PaymentStatus)";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("PaymentId", OracleDbType.Int32).Value = int.Parse(txtPaymentId.Text);
                    cmd.Parameters.Add("OrderId", OracleDbType.Int32).Value = int.Parse(txtOrderId.Text);
                    cmd.Parameters.Add("PaymentAmount", OracleDbType.Decimal).Value = decimal.Parse(txtPaymentAmount.Text);
                    cmd.Parameters.Add("PaymentDate", OracleDbType.Varchar2).Value = txtPaymentDate.Text;
                    cmd.Parameters.Add("PaymentStatus", OracleDbType.Varchar2).Value = txtPaymentStatus.Text;

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Payment added successfully.");
                    LoadPayments();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding payment: {ex.Message}");
            }
        }

        private void UpdatePayment()
        {
            try
            {
                string query = "UPDATE Payment SET OrderId = :OrderId, PaymentAmount = :PaymentAmount, " +
                               "PaymentDate = TO_DATE(:PaymentDate, 'YYYY-MM-DD'), PaymentStatus = :PaymentStatus " +
                               "WHERE PaymentId = :PaymentId";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("OrderId", OracleDbType.Int32).Value = int.Parse(txtOrderId.Text);
                    cmd.Parameters.Add("PaymentAmount", OracleDbType.Decimal).Value = decimal.Parse(txtPaymentAmount.Text);
                    cmd.Parameters.Add("PaymentDate", OracleDbType.Varchar2).Value = txtPaymentDate.Text;
                    cmd.Parameters.Add("PaymentStatus", OracleDbType.Varchar2).Value = txtPaymentStatus.Text;
                    cmd.Parameters.Add("PaymentId", OracleDbType.Int32).Value = int.Parse(txtPaymentId.Text);

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Payment updated successfully.");
                    LoadPayments();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating payment: {ex.Message}");
            }
        }

        private void DeletePayment()
        {
            try
            {
                string query = "DELETE FROM Payment WHERE PaymentId = :PaymentId";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("PaymentId", OracleDbType.Int32).Value = int.Parse(txtPaymentId.Text);

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Payment deleted successfully.");
                    LoadPayments();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting payment: {ex.Message}");
            }
        }
    }
}

