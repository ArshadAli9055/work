﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace WinFormsApp1
{
    public partial class Form7 : Form
    {
        private TextBox txtDiscountId, txtDiscountCode, txtDiscountType, txtDiscountValue, txtStartDate, txtEndDate, txtProductId;
        private Button btnLoadDiscounts, btnAddDiscount, btnUpdateDiscount, btnDeleteDiscount;
        private DataGridView dataGridViewDiscounts;
        private OracleConnection dbConnection;

        public Form7()
        {
            InitializeComponent();
            InitializeDatabaseConnection();
            InitializeCustomComponents();
        }

        // Initialize Database Connection
        private void InitializeDatabaseConnection()
        {
            string connectionString = "User Id=PROJECT;Password=123;Data Source=//localhost:1521/XE";
            dbConnection = new OracleConnection(connectionString);
        }

        // Initialize Custom Components
        private void InitializeCustomComponents()
        {
            // Title Label
            Label lblTitle = new Label()
            {
                Text = "Discount Management",
                Font = new Font("Arial", 18, FontStyle.Bold),
                Location = new Point(250, 10),
                Size = new Size(400, 40),
                TextAlign = ContentAlignment.MiddleCenter
            };
            Controls.Add(lblTitle);

            // Labels and Textboxes
            Controls.Add(CreateLabel("Discount ID:", 20, 70));
            Controls.Add(CreateLabel("Discount Code:", 20, 120));
            Controls.Add(CreateLabel("Discount Type:", 20, 170));
            Controls.Add(CreateLabel("Discount Value:", 20, 220));
            Controls.Add(CreateLabel("Start Date (YYYY-MM-DD):", 20, 270));
            Controls.Add(CreateLabel("End Date (YYYY-MM-DD):", 20, 320));
            Controls.Add(CreateLabel("Product ID:", 20, 370));

            txtDiscountId = CreateTextBox(200, 70);
            txtDiscountCode = CreateTextBox(200, 120);
            txtDiscountType = CreateTextBox(200, 170);
            txtDiscountValue = CreateTextBox(200, 220);
            txtStartDate = CreateTextBox(200, 270);
            txtEndDate = CreateTextBox(200, 320);
            txtProductId = CreateTextBox(200, 370);

            Controls.AddRange(new Control[] { txtDiscountId, txtDiscountCode, txtDiscountType, txtDiscountValue, txtStartDate, txtEndDate, txtProductId });

            // DataGridView
            dataGridViewDiscounts = new DataGridView()
            {
                Location = new Point(420, 70),
                Size = new Size(450, 300),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            Controls.Add(dataGridViewDiscounts);

            // Buttons
            btnLoadDiscounts = CreateButton("Load Discounts", 420, 400, Color.LightBlue);
            btnAddDiscount = CreateButton("Add Discount", 540, 400, Color.LightGreen);
            btnUpdateDiscount = CreateButton("Update Discount", 660, 400, Color.Gold);
            btnDeleteDiscount = CreateButton("Delete Discount", 780, 400, Color.Salmon);

            Controls.AddRange(new Control[] { btnLoadDiscounts, btnAddDiscount, btnUpdateDiscount, btnDeleteDiscount });

            // Event Handlers
            btnLoadDiscounts.Click += BtnLoadDiscounts_Click;
            btnAddDiscount.Click += BtnAddDiscount_Click;
            btnUpdateDiscount.Click += BtnUpdateDiscount_Click;
            btnDeleteDiscount.Click += BtnDeleteDiscount_Click;
        }

        // Helper Methods to Create UI Components
        private Label CreateLabel(string text, int x, int y)
        {
            return new Label()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(170, 30)
            };
        }

        private TextBox CreateTextBox(int x, int y)
        {
            return new TextBox()
            {
                Location = new Point(x, y),
                Size = new Size(200, 25)
            };
        }

        private Button CreateButton(string text, int x, int y, Color color)
        {
            return new Button()
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(100, 40),
                BackColor = color,
                FlatStyle = FlatStyle.Flat
            };
        }

        // Event Handlers for Buttons
        private void BtnLoadDiscounts_Click(object sender, EventArgs e)
        {
            LoadDiscounts();
        }

        private void BtnAddDiscount_Click(object sender, EventArgs e)
        {
            AddDiscount();
        }

        private void BtnUpdateDiscount_Click(object sender, EventArgs e)
        {
            UpdateDiscount();
        }

        private void BtnDeleteDiscount_Click(object sender, EventArgs e)
        {
            DeleteDiscount();
        }

        // Database Methods
        private void LoadDiscounts()
        {
            try
            {
                string query = "SELECT * FROM Discount ORDER BY DiscountId";
                OracleDataAdapter adapter = new OracleDataAdapter(query, dbConnection);
                DataTable discountsTable = new DataTable();
                adapter.Fill(discountsTable);
                dataGridViewDiscounts.DataSource = discountsTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading discounts: {ex.Message}");
            }
        }

        private void AddDiscount()
        {
            try
            {
                string query = "INSERT INTO Discount (DiscountId, DiscountCode, DiscountType, DiscountValue, StartDate, EndDate, ProductId) " +
                               "VALUES (:DiscountId, :DiscountCode, :DiscountType, :DiscountValue, TO_DATE(:StartDate, 'YYYY-MM-DD'), TO_DATE(:EndDate, 'YYYY-MM-DD'), :ProductId)";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("DiscountId", OracleDbType.Int32).Value = int.Parse(txtDiscountId.Text);
                    cmd.Parameters.Add("DiscountCode", OracleDbType.Varchar2).Value = txtDiscountCode.Text;
                    cmd.Parameters.Add("DiscountType", OracleDbType.Varchar2).Value = txtDiscountType.Text;
                    cmd.Parameters.Add("DiscountValue", OracleDbType.Decimal).Value = decimal.Parse(txtDiscountValue.Text);
                    cmd.Parameters.Add("StartDate", OracleDbType.Varchar2).Value = txtStartDate.Text;
                    cmd.Parameters.Add("EndDate", OracleDbType.Varchar2).Value = txtEndDate.Text;
                    cmd.Parameters.Add("ProductId", OracleDbType.Int32).Value = int.Parse(txtProductId.Text);

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Discount added successfully.");
                    LoadDiscounts();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding discount: {ex.Message}");
            }
        }

        private void UpdateDiscount()
        {
            try
            {
                string query = "UPDATE Discount SET DiscountCode = :DiscountCode, DiscountType = :DiscountType, " +
                               "DiscountValue = :DiscountValue, StartDate = TO_DATE(:StartDate, 'YYYY-MM-DD'), " +
                               "EndDate = TO_DATE(:EndDate, 'YYYY-MM-DD'), ProductId = :ProductId WHERE DiscountId = :DiscountId";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("DiscountCode", OracleDbType.Varchar2).Value = txtDiscountCode.Text;
                    cmd.Parameters.Add("DiscountType", OracleDbType.Varchar2).Value = txtDiscountType.Text;
                    cmd.Parameters.Add("DiscountValue", OracleDbType.Decimal).Value = decimal.Parse(txtDiscountValue.Text);
                    cmd.Parameters.Add("StartDate", OracleDbType.Varchar2).Value = txtStartDate.Text;
                    cmd.Parameters.Add("EndDate", OracleDbType.Varchar2).Value = txtEndDate.Text;
                    cmd.Parameters.Add("ProductId", OracleDbType.Int32).Value = int.Parse(txtProductId.Text);
                    cmd.Parameters.Add("DiscountId", OracleDbType.Int32).Value = int.Parse(txtDiscountId.Text);

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Discount updated successfully.");
                    LoadDiscounts();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating discount: {ex.Message}");
            }
        }

        private void DeleteDiscount()
        {
            try
            {
                string query = "DELETE FROM Discount WHERE DiscountId = :DiscountId";
                using (OracleCommand cmd = new OracleCommand(query, dbConnection))
                {
                    cmd.Parameters.Add("DiscountId", OracleDbType.Int32).Value = int.Parse(txtDiscountId.Text);

                    dbConnection.Open();
                    cmd.ExecuteNonQuery();
                    dbConnection.Close();

                    MessageBox.Show("Discount deleted successfully.");
                    LoadDiscounts();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting discount: {ex.Message}");
            }
        }
    }
}

